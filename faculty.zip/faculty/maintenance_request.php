<?php
session_start(); // Start the session at the very top

// Check if the email is stored in the session
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Database connection details
$host = 'localhost';
$db = 'sqms';
$user = 'root';
$pass = '';
$port = 3308;

// Create a connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables for pre-filled data
$campusName = "";
$blockName = "";
$quarterType = "";
$flatNo = "";
$residentName = "";

// Get resident information to pre-fill the form
$sql_residents = "SELECT r.*, cq.campus_name, cq.block_name, cq.type AS quarter_type 
                  FROM residents r 
                  JOIN campus_quarters cq ON r.campus_quarter_id = cq.campus_quarter_id 
                  WHERE r.email = ?";
$stmt_residents = $conn->prepare($sql_residents);
$stmt_residents->bind_param("s", $email);
$stmt_residents->execute();
$result = $stmt_residents->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $campusName = $row['campus_name'];
    $blockName = $row['block_name'];
    $quarterType = $row['quarter_type'];
    $flatNo = $row['flat_no'];
    $residentName = $row['name'];
}

// Process form submission
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $campusName = $_POST['campus_name'];
    $blockName = $_POST['block_name'];
    $quarterType = $_POST['quarter_type'];
    $flatNo = $_POST['flat_no'];
    $residentName = $_POST['resident_name'];
    $email = $_POST['email'];
    $maintenanceReason = $_POST['maintenance_reason'];
    $requestDate = date('Y-m-d');
    $status = 'Pending'; // Default status for new requests

    // Prepare SQL statement for inserting maintenance request
    $sql_insert = "INSERT INTO maintenance (campus_name, block_name, quarter_type, flat_no, resident_name, email, 
                   maintenance_reason, request_date, status) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param(
        "sssssssss",
        $campusName,
        $blockName,
        $quarterType,
        $flatNo,
        $residentName,
        $email,
        $maintenanceReason,
        $requestDate,
        $status
    );

    if ($stmt_insert->execute()) {
        $message = '<div class="alert alert-success">Maintenance request submitted successfully!</div>';
        echo '<script>
        setTimeout(function() {
            window.location.href = "status.php";
        }, 3000); // Redirect after 3 seconds
        </script>';
    } else {
        $message = '<div class="alert alert-danger">Error: ' . $stmt_insert->error . '</div>';
    }

    $stmt_insert->close();
}

// Close the residents statement
$stmt_residents->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Request</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-title {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
        }

        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: #fff;
        }

        .form-control:disabled {
            background-color: #e9ecef;
        }

        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }

        .submit-btn {
            padding: 12px 30px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: 0 auto;
        }

        .submit-btn:hover {
            background-color: #0056b3;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
    <link rel="stylesheet" href="../faculty/css/form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>

    <div class="main-content">
        <div class="section-container">
            <h2 class="section-title">Submit Maintenance Request</h2>
            <div class="container">
                <?php echo $message; ?>
                <div class="form-container">
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="campus_name">Campus Name</label>
                                    <input type="text" class="form-control" id="campus_name" name="campus_name"
                                        value="<?php echo htmlspecialchars($campusName); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="block_name">Block Name</label>
                                    <input type="text" class="form-control" id="block_name" name="block_name"
                                        value="<?php echo htmlspecialchars($blockName); ?>" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="quarter_type">Quarter Type</label>
                                    <input type="text" class="form-control" id="quarter_type" name="quarter_type"
                                        value="<?php echo htmlspecialchars($quarterType); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="flat_no">Flat Number</label>
                                    <input type="text" class="form-control" id="flat_no" name="flat_no"
                                        value="<?php echo htmlspecialchars($flatNo); ?>" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="resident_name">Resident Name</label>
                            <input type="text" class="form-control" id="resident_name" name="resident_name"
                                value="<?php echo htmlspecialchars($residentName); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label for="resident_name">Email</label>
                            <input type="text" class="form-control" id="email" name="email"
                                value="<?php echo htmlspecialchars($email); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label for="maintenance_reason">Maintenance Details <span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" id="maintenance_reason" name="maintenance_reason"
                                placeholder="Please describe the maintenance or repair needed in detail"
                                required></textarea>
                            <small class="form-text text-muted">Be specific about the issue, location within your
                                quarters, and any other relevant details.</small>
                        </div>

                        <button type="submit" class="btn btn-primary submit-btn">Submit Request</button>
                    </form>

                    <a href="index.php" class="back-link">← Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>

    <?php include_once('../faculty/footer.php'); ?>
</body>

</html>