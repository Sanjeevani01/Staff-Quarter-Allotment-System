<?php


session_start();  // Start the session



// Check if the email session is set
if (!isset($_SESSION['email'])) {
    // If not, redirect to the login page
    header('Location: login_emp.php');  // Replace with the actual login page URL
    exit();  // Always call exit after redirect to prevent further code execution
}



// Destroy the session
$_SESSION = [];  // Clear the session array
session_unset();  // Unset all session variables
session_destroy();  // Destroy the session

// Optionally, clear the cookies (if any)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Redirect the user back to the login page
header('Location: login_emp.php');  // Redirect to your login page
exit();
?>
