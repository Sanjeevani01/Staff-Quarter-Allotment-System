<?php
session_start(); // Start session to access session variables

// Check if the email session is set
if (!isset($_SESSION['email'])) {
    // If not, redirect to the login page
    header('Location: login_emp.php');  // Replace with the actual login page URL
    exit();  // Always call exit after redirect to prevent further code execution
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
CREATE TABLE quat_perf (
    quat_perf_id INT AUTO_INCREMENT PRIMARY KEY,
    quarter_type VARCHAR(20) NOT NULL,
    reason VARCHAR(512) NOT NULL,
    preferred_location VARCHAR(100) NOT NULL,
    fac_id_fk INT NOT NULL,
    CONSTRAINT fk_faculty FOREIGN KEY (fac_id_fk) REFERENCES faculty_login(fac_id)
        
)
";

if ($conn->query($sql) !== TRUE) {
    echo "<script>alert('Error creating table: " . $conn->error . "');</script>";
}

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $quarterPreference = $_POST['quarterPreference'];
    $reasonPreference = $_POST['reasonPreference'];
    $preferredLocation = $_POST['preferredLocation'];

    // Prepare a SQL statement to get the fac_id based on the email stored in the session
    $fac_id_stmt = $conn->prepare("SELECT fac_id FROM faculty_login WHERE email = ?");
    $fac_id_stmt->bind_param("s", $email);
    $fac_id_stmt->execute();
    $fac_id_stmt->bind_result($fac_id_fk);
    $fac_id_stmt->fetch();
    $fac_id_stmt->close();

    if ($fac_id_fk) {
        // Insert quarter preference into the database
        $stmt = $conn->prepare("INSERT INTO quat_perf (quarter_type, reason, preferred_location, fac_id_fk) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $quarterPreference, $reasonPreference, $preferredLocation, $fac_id_fk);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Quarter preference saved successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Faculty ID not found.";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quarter Preference</title>
    <link rel="stylesheet" href="../faculty/css/new_form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .error {
            color: red;
            font-size: 0.875rem;
        }
    </style>
</head>

<body>
    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>
    <div style="height: 130px;">
        <!-- sagli kade paste karaycha aahe for height-->
    </div>
    <div class="progress-bar">
        <ul>
            <li class="active"><a href="personal_info.php">Personal <br> Information</a></li>
            <li><a href="fam_det.php">Family <br> Details</a></li>
            <li><a href="emp_det.php">Employment <br> Details</a></li>
            <li><a href="quat_pref.php">Quarter <br> Preference</a></li>
            <li><a href="docs.php">Upload <br> Documents</a></li>
        </ul>
        <div class="progress-line">
            <div class="filled-line"></div>
        </div>
    </div>

    <div class="container">
        <h2>Quarter Preference</h2>
        <form id="quarterPreferenceForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
            <!-- Quarter Preference Dropdown -->
            <div class="mb-3">
                <label for="quarterPreference" class="form-label">Quarter Preference</label>
                <select class="form-select" id="quarterPreference" name="quarterPreference" required>
                    <option value="">Select...</option>
                    <option value="1bhk">1BHK</option>
                    <option value="2bhk">2BHK</option>
                    <option value="3bhk">3BHK</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="reasonPreference" class="form-label">Reason for Preference</label>
                <textarea class="form-control" id="reasonPreference" name="reasonPreference" rows="4" placeholder="Please provide your reason..." required></textarea>
                <div id="reasonError" class="error"></div>
            </div>

            <!-- Preferred Location Input -->
            <div class="mb-3">
                <label for="preferredLocation" class="form-label">Preferred Location (if any)</label>
                <input type="text" class="form-control" id="preferredLocation" name="preferredLocation" placeholder="Enter preferred location">
                <div id="locationError" class="error"></div>
            </div>

            <!-- Buttons -->
            <div class="btn-container">
                <button type="submit" class="btn btn-success" onclick="saveForm()">Save</button>
                <button type="button" class="btn btn-primary" onclick="nextPage()">Next</button>
            </div>
        </form>
    </div>

    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script> -->


    <?php include_once('../faculty/footer.php'); ?>
    <script>
        // Function to set the active step and store it in localStorage
        function setActiveStep(index) {
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;
            if (index >= 0 && index < totalSteps) {
                localStorage.setItem('activeStep', index); // Store active step
                updateProgressBar(index);
            }
        }

        // Function to update progress bar based on active step
        function updateProgressBar(activeStep) {
            const steps = document.querySelectorAll('.progress-bar ul li');
            const progressLine = document.querySelector('.filled-line');

            // Update step classes
            steps.forEach((step, i) => {
                if (i <= activeStep) {
                    step.classList.add('active');
                } else {
                    step.classList.remove('active');
                }
            });

            // Update the width of the progress line
            const stepWidth = ((activeStep + 1) / steps.length) * 100;
            progressLine.style.width = stepWidth + '%';
        }

        // Function to handle "Next" button click
        function nextPage() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;

            if (activeStep < totalSteps - 1) {
                setActiveStep(activeStep + 1); // Move to the next step
                // Optionally navigate to the next form page based on the current active step
                if (activeStep === 0) {
                    window.location.href = 'fam_det.php';
                } else if (activeStep === 1) {
                    window.location.href = 'emp_det.php';
                } else if (activeStep === 2) {
                    window.location.href = 'quat_pref.php';
                } else if (activeStep === 3) {
                    window.location.href = 'docs.php';
                }
            }
        }

        // On page load, get the active step from localStorage and update the progress bar
        window.onload = function() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            updateProgressBar(activeStep);

            // Add click events to steps
            const steps = document.querySelectorAll('.progress-bar ul li');
            steps.forEach((step, i) => {
                step.addEventListener('click', () => setActiveStep(i));
            });
        }
        document.getElementById('quarterPreferenceForm').addEventListener('input', function(e) {
            // Real-time Validation for Reason for Preference
            const reason = document.getElementById('reasonPreference').value.trim();
            const reasonError = document.getElementById('reasonError');
            if (reason.length < 10) {
                reasonError.textContent = "Reason for preference must be at least 10 characters.";
            } else {
                reasonError.textContent = "";
            }

            // Real-time Validation for Preferred Location
            const location = document.getElementById('preferredLocation').value.trim();
            const locationError = document.getElementById('locationError');
            if (location.length > 0 && location.length < 3) {
                locationError.textContent = "Preferred location must be at least 3 characters if entered.";
            } else {
                locationError.textContent = "";
            }

            // Enable or disable submit button based on validation
            const submitBtn = document.getElementById('submitBtn');
            if (reason.length >= 10 && (location.length >= 3 || location.length === 0)) {
                submitBtn.disabled = false;
            } else {
                submitBtn.disabled = true;
            }
        });

        // Handle form submission
        document.getElementById('quarterPreferenceForm').addEventListener('submit', function(e) {
            // Final validation before submitting form
            const reason = document.getElementById('reasonPreference').value.trim();
            const location = document.getElementById('preferredLocation').value.trim();

            if (reason.length < 10) {
                e.preventDefault();
                alert("Please provide a reason with at least 10 characters.");
                return false;
            }

            if (location.length > 0 && location.length < 3) {
                e.preventDefault();
                alert("Preferred location must be at least 3 characters.");
                return false;
            }
        });
    </script>



</body>

</html>