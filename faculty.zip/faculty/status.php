<?php
session_start(); // Start the session at the very top

// Check if the email is stored in the session
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Database connection details
$host = 'localhost';
$db = 'sqms';
$user = 'root';
$pass = '';
$port = 3308;

// Create a connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the fac_id from the faculty_login table using the email
$sql = "SELECT fac_id FROM faculty_login WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email); // Bind the email to the SQL query
$stmt->execute();
$result = $stmt->get_result();

// Initialize a variable to check if user is found
$userFound = false;
$personalInfo = null;
$residentInfo = null;

// Check if the email exists, fetch the fac_id
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $fac_id = $row['fac_id']; // Store the faculty's ID
    $userFound = true; // User found

    // SQL query to fetch application data from personal_info using fac_id_fk
    $sql = "SELECT emp_id, name, phone_no, email, date_of_joining, principle_status, admin_status FROM personal_info WHERE fac_id_fk = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $fac_id); // Bind fac_id to the SQL query
    $stmt->execute();
    $personalInfo = $stmt->get_result();
    
    // SQL query to fetch data from residents table based on email
    $sql_residents = "SELECT r.*, cq.campus_name, cq.block_name, cq.type AS quarter_type 
                      FROM residents r 
                      JOIN campus_quarters cq ON r.campus_quarter_id = cq.campus_quarter_id 
                      WHERE r.email = ?";
    $stmt_residents = $conn->prepare($sql_residents);
    $stmt_residents->bind_param("s", $email);
    $stmt_residents->execute();
    $residentInfo = $stmt_residents->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application and Residence Status</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f5f5f5;
            color: #333;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .status {
            font-weight: bold;
        }

        .status.under-scrutiny {
            color: #ff9800;
        }

        .status.approved {
            color: #4caf50;
        }

        .status.rejected {
            color: #f44336;
        }

        .status.pending {
            color: #ff9800;
        }

        .section-container {
            margin-top: 100px;
            margin-bottom: 20px;
        }

        .section-title {
            margin-top: 20px;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
            font-size: 24px;
            position: relative;
            padding-bottom: 10px;
        }

        .section-title:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80%;
            height: 1px;
            background-color: #ddd;
        }

        .no-data {
            padding: 20px;
            text-align: center;
            color: #666;
            font-style: italic;
        }
        
        /* Maintenance button styles */
        .maintenance-section {
            text-align: center;
            margin-bottom: 50px;
        }
        
        .maintenance-btn {
            padding: 12px 30px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .maintenance-btn:hover {
            background-color: #0056b3;
        }
    </style>
    <link rel="stylesheet" href="../faculty/css/form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>
    
    <div class="main-content">
        <!-- Application Status Section -->
        <div class="section-container">
            <h2 class="section-title">Employee Application Status</h2>
            <div class="container">
                <table>
                    <tr>
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Phone No</th>
                        <th>Email Add</th>
                        <th>DOJ</th>
                        <th>Principle Status</th>
                        <th>Admin Status</th>
                    </tr>
                    <?php
                    // Check if the user was found and if applications exist
                    if ($userFound && $personalInfo) {
                        // Check if there are results for applications
                        if ($personalInfo->num_rows > 0) {
                            // Output the table rows dynamically
                            while ($row = $personalInfo->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['emp_id']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['phone_no']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                echo "<td>" . date('d-M-Y', strtotime($row['date_of_joining'])) . "</td>";
                                
                                // Display Principle Status
                                echo "<td class='status " . strtolower(str_replace(' ', '-', $row['principle_status'])) . "'>" . 
                                     htmlspecialchars($row['principle_status']) . "</td>";
                                
                                // Display Admin Status with conditional text
                                $adminStatusDisplay = $row['admin_status'] == 'Approved' ? 'Approved' : 
                                                     ($row['admin_status'] == 'Rejected' ? 'Rejected' : 'Pending');
                                echo "<td class='status " . strtolower(str_replace(' ', '-', $adminStatusDisplay)) . "'>" . 
                                     htmlspecialchars($adminStatusDisplay) . "</td>";
                                
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='no-data'>No applications found.</td></tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7' class='no-data'>User not found.</td></tr>";
                    }
                    ?>
                </table>
            </div>
        </div>

        <!-- Residence Information Section -->
        <div class="section-container">
            <h2 class="section-title">Residence Information</h2>
            <div class="container">
                <table>
                    <tr>
                        <th>Campus</th>
                        <th>Block</th>
                        <th>Quarter Type</th>
                        <th>Flat No</th>
                        <th>Resident Name</th>
                        <th>Designation</th>
                        <th>Department</th>
                        <th>Institute</th>
                    </tr>
                    <?php
                    // Check if resident information exists
                    if ($residentInfo && $residentInfo->num_rows > 0) {
                        while ($row = $residentInfo->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['campus_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['block_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['quarter_type']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['flat_no']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['designation']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['department']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['institute']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8' class='no-data'>No residence information found. You may not have been assigned quarters yet.</td></tr>";
                    }

                    // Close all statements and connection
                    if (isset($stmt)) $stmt->close();
                    if (isset($stmt_residents)) $stmt_residents->close();
                    $conn->close();
                    ?>
                </table>
            </div>
        </div>
        
        <!-- Maintenance Request Section -->
        <div class="section-container maintenance-section">
            <h2 class="section-title">Maintenance Request</h2>
            <div class="container">
                <p>Need repairs or maintenance for your quarters? Click the button below to submit a request.</p>
                <a href="maintenance_request.php" class="btn btn-primary maintenance-btn">Submit Maintenance Request</a>
            </div>
        </div>
    </div>

    <?php include_once('../faculty/footer.php'); ?>
</body>

</html>