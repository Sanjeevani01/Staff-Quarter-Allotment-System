<!-- ======= Header ======= -->
<header id="header" class="header fixed-top ">
    <div class="container d-flex align-items-center justify-content-between">
        <!-- Logo -->
        <!-- <link rel="icon" type="image/x-icon" href="./src/favicon.ico"> -->
        <!-- <img src="https://admissions.sinhgad.edu/application/views/image/OIP.png" height="100" width="100"  style="margin-top: 10px;" alt="Sinhgad Technical Education Society,Pune" class="img-fluid" > -->
        <img src="../faculty/src/si-logo.png" height="100" width="100" style="margin-top: 10px;" alt="Sinhgad Technical Education Society,Pune" class="img-fluid">
        <!-- Text logo  class="img-fluid" -->
        <h1 class="fs-5 fw-light text-black ms-3 d-none d-md-block">Sinhgad Technical Education Society,Pune</h1>
        <!-- Mobile Logo and Toggle -->

        <!-- Social Media Links -->
        <div class="social-links ms-auto">
            <a href="https://twitter.com/SinhgadCollege" class="twitter"><i class="bi bi-twitter text-white me-3"></i></a>
            <a href="https://www.facebook.com/SinhgadInstitutes.STES" class="facebook"><i class="bi bi-facebook text-white me-3"></i></a>
            <a href="https://www.instagram.com/sinhgadinstitutes/" class="instagram"><i class="bi  bi-instagram text-white me-3"></i></a>
            <a href="https://in.linkedin.com/school/sinhgad-institutes/" class="linkedin"><i class="bi bi-linkedin text-white "></i></a>
        </div>

        <!-- Navbar Menu -->
        <nav id="navbar" class="navbar">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="apply.php">Apply</a></li>
                <li><a href="status.php">Status</a></li>
                <li><a href="maintenance.php">Maintenance</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="logout.php">Logout</a></li>

            </ul>
        </nav><!-- .navbar -->


    </div>
</header>


<!-- End Header -->