<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['email'])) {
    header('Location: login_emp.php');
    exit();
}

$conn = new mysqli("localhost", "root", "", "sqms", 3308);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to create table
$sql = "CREATE TABLE IF NOT EXISTS fam_det (
    fam_det_id INT AUTO_INCREMENT PRIMARY KEY,
    marital_status VARCHAR(32) NOT NULL,
    medical_condition VARCHAR(50) NOT NULL,
    medical_details VARCHAR(511) NOT NULL,
    disabilities VARCHAR(50) NOT NULL,
    disabilities_details VARCHAR(511) NOT NULL,
    fac_id_fk INT NOT NULL,
    CONSTRAINT fk_fac_id FOREIGN KEY (fac_id_fk) REFERENCES faculty_login(fac_id)
)";

if ($conn->query($sql) !== TRUE) {
    echo "<script>alert('Error creating table: " . $conn->error . "');</script>";
}

$email = $_SESSION['email'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $maritalStatus = $_POST['maritalStatus'];
    $medicalCondition = $_POST['medicalCondition'];
    $medicalDetails = $_POST['medicalDetails'] ?? '';
    $disabilities = $_POST['disabilities'];
    $disabilitiesDetails = $_POST['disabilitiesDetails'] ?? '';
    $family_members = $_POST['familyMembers'] ?? [];

    $fac_stmt = $conn->prepare("SELECT fac_id FROM faculty_login WHERE email = ?");
    $fac_stmt->bind_param("s", $email);
    $fac_stmt->execute();
    $fac_stmt->bind_result($fac_id_fk);
    $fac_stmt->fetch();
    $fac_stmt->close();

    if ($fac_id_fk) {
        $stmt = $conn->prepare("INSERT INTO fam_det (marital_status, medical_condition, medical_details, disabilities, disabilities_details, fac_id_fk) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssi", $maritalStatus, $medicalCondition, $medicalDetails, $disabilities, $disabilitiesDetails, $fac_id_fk);
        
        if ($stmt->execute()) {
            $fam_det_id = $stmt->insert_id;

            $member_stmt = $conn->prepare("INSERT INTO family_members (fm_name, fm_relation, fm_age, fm_occupation, fam_det_id_fk) VALUES (?, ?, ?, ?, ?)");
            foreach ($family_members as $member) {
                $member_stmt->bind_param("ssisi", $member['name'], $member['relation'], $member['age'], $member['occupation'], $fam_det_id);
                if (!$member_stmt->execute()) {
                    echo "Error inserting member: " . $member_stmt->error;
                }
            }
            $member_stmt->close();
            echo "<div class='alert alert-success'>Family details saved successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error inserting family details: " . $stmt->error . "</div>";
        }
        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Family Details</title>
    <link rel="stylesheet" href="../faculty/css/new_form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<?php include_once('../faculty/header.php'); ?>
<?php include_once('../faculty/emp_left_nav.php'); ?>
<div style="height: 130px;"></div>

<div class="progress-bar">
    <ul>
        <li><a href="personal_info.php">Personal <br> Information</a></li>
        <li><a href="fam_det.php">Family <br> Details</a></li>
        <li><a href="emp_det.php">Employment <br> Details</a></li>
        <li><a href="quat_pref.php">Quarter <br> Preference</a></li>
        <li><a href="docs.php">Upload <br> Documents</a></li>
    </ul>
    <div class="progress-line"><div class="filled-line"></div></div>
</div>

<div class="container mt-5">
    <h2 class="mb-4">Family Details Form</h2>
    <form id="familyDetailsForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" onsubmit="return validateForm()">
        <div class="mb-3">
            <label for="maritalStatus" class="form-label">Marital Status</label>
            <select class="form-select" id="maritalStatus" name="maritalStatus" required>
                <option value="">Choose...</option>
                <option value="single">Single</option>
                <option value="married">Married</option>
                <option value="divorced">Divorced</option>
                <option value="widowed">Widowed</option>
            </select>
        </div>

        <div class="mb-3">
            <h4>Family Members</h4>
            <table class="table" id="familyMembersTable">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Relation</th>
                    <th>Age</th>
                    <th>Occupation</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody id="familyMembersBody"></tbody>
            </table>
            <button type="button" class="btn btn-primary" onclick="addFamilyMember()">Add Family Member</button>
        </div>

        <div class="mb-3">
            <h4>Special Needs</h4>

            <!-- Medical Condition -->
            <label class="form-label">Medical Condition:</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="medicalCondition" id="medicalYes" value="yes" onchange="toggleDescription('medical', true)">
                <label class="form-check-label" for="medicalYes">Yes</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="medicalCondition" id="medicalNo" value="no" onchange="toggleDescription('medical', false)">
                <label class="form-check-label" for="medicalNo">No</label>
            </div>

            <div id="medicalDescription" style="display: none;">
                <label for="medicalDetails" class="form-label">Description:</label>
                <textarea class="form-control" id="medicalDetails" name="medicalDetails" rows="3"></textarea>
            </div>

            <!-- Disabilities -->
            <label class="form-label mt-3">Disabilities:</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="disabilities" id="disabilitiesYes" value="yes" onchange="toggleDescription('disabilities', true)">
                <label class="form-check-label" for="disabilitiesYes">Yes</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="disabilities" id="disabilitiesNo" value="no" onchange="toggleDescription('disabilities', false)">
                <label class="form-check-label" for="disabilitiesNo">No</label>
            </div>

            <div id="disabilitiesDescription" style="display: none;">
                <label for="disabilitiesDetails" class="form-label">Description:</label>
                <textarea class="form-control" id="disabilitiesDetails" name="disabilitiesDetails" rows="3"></textarea>
            </div>
        </div>

        <button type="submit" class="btn btn-success me-2">Save</button>
        <button type="button" class="btn btn-primary" onclick="nextPage()">Next</button>
    </form>
</div>

<?php include_once('../faculty/footer.php'); ?>

<script>
function toggleDescription(type, show) {
    const descriptionDiv = document.getElementById(`${type}Description`);
    descriptionDiv.style.display = show ? "block" : "none";
}

function addFamilyMember() {
    const table = document.getElementById('familyMembersBody');
    const index = table.rows.length;

    const row = table.insertRow();
    row.innerHTML = `
        <td><input type="text" class="form-control" name="familyMembers[${index}][name]" required></td>
        <td><input type="text" class="form-control" name="familyMembers[${index}][relation]" required></td>
        <td><input type="number" class="form-control" name="familyMembers[${index}][age]" required min="0"></td>
        <td><input type="text" class="form-control" name="familyMembers[${index}][occupation]" required></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="deleteFamilyMember(this)">Delete</button></td>
    `;
}

function deleteFamilyMember(button) {
    const row = button.closest('tr');
    row.remove();
}

function validateForm() {
    const maritalStatus = document.getElementById('maritalStatus').value;
    if (!maritalStatus) {
        alert("Please select marital status.");
        return false;
    }

    const familyRows = document.querySelectorAll('#familyMembersBody tr');
    if (familyRows.length === 0) {
        alert("Please add at least one family member.");
        return false;
    }

    const medicalYes = document.getElementById("medicalYes").checked;
    const medicalNo = document.getElementById("medicalNo").checked;
    if (!medicalYes && !medicalNo) {
        alert("Please select medical condition status.");
        return false;
    }

    if (medicalYes && document.getElementById("medicalDetails").value.trim() === "") {
        alert("Please enter medical condition details.");
        return false;
    }

    const disabilitiesYes = document.getElementById("disabilitiesYes").checked;
    const disabilitiesNo = document.getElementById("disabilitiesNo").checked;
    if (!disabilitiesYes && !disabilitiesNo) {
        alert("Please select disability status.");
        return false;
    }

    if (disabilitiesYes && document.getElementById("disabilitiesDetails").value.trim() === "") {
        alert("Please enter disability details.");
        return false;
    }

    return true;
}

function setActiveStep(index) {
    localStorage.setItem('activeStep', index);
    updateProgressBar(index);
}

function updateProgressBar(activeStep) {
    const steps = document.querySelectorAll('.progress-bar ul li');
    const progressLine = document.querySelector('.filled-line');

    steps.forEach((step, i) => {
        step.classList.toggle('active', i <= activeStep);
    });

    const stepWidth = ((activeStep + 1) / steps.length) * 100;
    progressLine.style.width = stepWidth + '%';
}

window.onload = function() {
    const activeStep = parseInt(localStorage.getItem('activeStep')) || 1;
    updateProgressBar(activeStep);
};

const steps = document.querySelectorAll('.progress-bar ul li');
steps.forEach((step, i) => {
    step.addEventListener('click', () => setActiveStep(i));
});

function nextPage() {
    const activeStep = parseInt(localStorage.getItem('activeStep')) || 1;
    setActiveStep(activeStep + 1);
    window.location.href = 'emp_det.php';
}
</script>

</body>
</html>
