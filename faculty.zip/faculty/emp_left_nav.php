<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar Example</title>
    <!-- CSS Files -->
    <link rel="stylesheet" href="application/views/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="application/views/assets/css/plugins.min.css" />
    <link rel="stylesheet" href="application/views/assets/css/kaiadmin.min.css" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="application/views/assets/css/demo.css" />
    <style>
        /* Apply gradient background color and transition to the sidebar */
        .sidebar {
            background-image: linear-gradient(to right, #48276A, #48276A);
            /* Gradient background */
            transition: opacity 300ms ease;
            /* Smooth transition effect for opacity */
            height: 100vh;
            /* Full viewport height */
            overflow: hidden;
            /* Hide scrollbar */
            color: white;
            /* Set text color to white */
        }

        /* Ensure transition works correctly if opacity is modified elsewhere */
        .sidebar.fade {
            opacity: 0.5;
            /* Example of reduced opacity, adjust as needed */
        }

        /* Sidebar content styles */
        .sidebar-logo {
            padding: 15px;
        }

        .logo-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }

        .nav-toggle {
            display: flex;
            gap: 5px;
        }

        .nav-toggle .btn {
            font-size: 20px;
        }

        .sidebar-content {
            padding: 10px;
        }

        .nav {
            margin: 0;
            padding: 0;
        }

        .nav ul {
            list-style: none;
            padding: 0;
        }

        .nav ul li {
            margin: 20px 0;
        }

        .nav ul li a {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
            /* Set link color to white */
            transition: color 300ms ease;
        }

        .nav ul li a i {
            margin-right: 10px;
        }

        .nav ul li.active a {
            color: white;
        }

        .nav ul li:not(.active):hover a {
            color: white;
        }

        .nav ul li .collapse {
            padding-left: 20px;
        }

        .nav ul li .collapse ul {
            padding: 0;
            margin: 0;
        }

        .nav ul li .collapse ul li a {
            color: rgba(255, 255, 255, 0.9);
            line-height: 2;
        }

        .nav ul li .collapse ul li a:hover {
            color: white;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <!-- Sidebar -->

        <!-- End Sidebar -->

        <!-- Optional JavaScript -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>