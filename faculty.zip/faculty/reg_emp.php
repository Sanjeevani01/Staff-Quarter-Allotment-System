<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table if it doesn't exist
$createTableQuery = "
CREATE TABLE IF NOT EXISTS faculty_login (
    fac_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
)";

if (!$conn->query($createTableQuery)) {
    die("Error creating table: " . $conn->error);
}

// Initialize error array
$errors = [];

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data and trim whitespace
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Validate name
    if (empty($name) || !preg_match("/^[a-zA-Z\s]+$/", $name)) {
        $errors['name'] = "Name should contain only alphabets and spaces.";
    }

    // Validate email
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Valid email address is required.";
    }

    // Check if email already exists
    $checkEmailQuery = "SELECT * FROM faculty_login WHERE email = ?";
    $stmt = $conn->prepare($checkEmailQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $errors['email'] = "User with this email already exists.";
    }

    // Validate password
    if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};\'":\\|,.<>\/?]).{8,}$/', $password)) {
        $errors['password'] = "Password must be at least 8 characters, and include at least one letter, one number, and one symbol.";
    }
    
    // Check for errors
    if (empty($errors)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL statement
        $sql = "INSERT INTO faculty_login (name, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $name, $email, $hashed_password);

        if ($stmt->execute()) {
            header("Location: login_emp.php");
            exit;
        }
    }
}

// Close connection
$conn->close();
?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../admin/css/style.css">
    <title>SIOM | Faculty Registration</title>
    <style>
        .error-message {
            color: red;
            font-size: 0.70em;
        }
    </style>
</head>
<body background="../faculty/src/wall11.jpg">
    <div class="wrapper">
        <h2>Faculty Registration</h2>

        <!-- Display server-side errors -->
        <?php if (!empty($errors)) { ?>
            <div style="color: red;">
                <?php foreach ($errors as $error) { echo "<p>$error</p>"; } ?>
            </div>
        <?php } ?>

        <form id="registrationForm" method="post" novalidate>
            <div class="input-box">
                <input type="text" placeholder="Enter your name" name="name" id="name" required value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                <span class="error-message" id="nameError"></span>
            </div>
            <div class="input-box">
                <input type="email" placeholder="Enter your email" name="email" id="email" required value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                <span class="error-message" id="emailError"></span>
            </div>
            <div class="input-box">
                <input type="password" placeholder="Create password" name="password" id="password" required>
                <span class="error-message" id="passwordError"></span>
            </div>

            <div class="policy">
                <input type="checkbox" id="termsCheckbox">
                <h3>I accept all terms & conditions</h3>
                <span class="error-message" id="termsError"></span>
            </div>
            <div class="input-box button">
                <input type="submit" value="Register Now">
            </div>
            <div class="text">
                <h3>Already have an account? <a href="../faculty/login_emp.php">Login now</a></h3>
            </div>
        </form>
    </div>

    <script>
        // JavaScript for client-side validation (same as your existing code)
        const nameInput = document.getElementById("name");
        const emailInput = document.getElementById("email");
        const passwordInput = document.getElementById("password");
        const termsCheckbox = document.getElementById("termsCheckbox");

        const nameError = document.getElementById("nameError");
        const emailError = document.getElementById("emailError");
        const passwordError = document.getElementById("passwordError");
        const termsError = document.getElementById("termsError");

        function validateName() {
            const namePattern = /^[a-zA-Z\s]+$/;
            if (!nameInput.value.trim()) {
                nameError.textContent = "Name is required.";
                return false;
            } else if (!namePattern.test(nameInput.value.trim())) {
                nameError.textContent = "Only alphabets and spaces allowed.";
                return false;
            }
            nameError.textContent = "";
            return true;
        }

        function validateEmail() {
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailInput.value.trim()) {
                emailError.textContent = "Email is required.";
                return false;
            } else if (!emailPattern.test(emailInput.value.trim())) {
                emailError.textContent = "Invalid email format.";
                return false;
            }
            emailError.textContent = "";
            return true;
        }

        function validatePassword() {
            const password = passwordInput.value;
            const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/;

            if (!passwordPattern.test(password)) {
                passwordError.textContent = "Min length 8, 1 letter, 1 symbol, 1 number.";
                return false;
            }
            passwordError.textContent = "";
            return true;
        }

        function validateTerms() {
            if (!termsCheckbox.checked) {
                termsError.textContent = "You must accept terms & conditions.";
                return false;
            }
            termsError.textContent = "";
            return true;
        }

        // Real-time validation listeners
        nameInput.addEventListener("input", validateName);
        emailInput.addEventListener("input", validateEmail);
        passwordInput.addEventListener("input", validatePassword);
        termsCheckbox.addEventListener("change", validateTerms);

        // Form submit validation
        document.getElementById("registrationForm").addEventListener("submit", function (e) {
            const isValid = validateName() & validateEmail() & validatePassword() & validateTerms();
            if (!isValid) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>
