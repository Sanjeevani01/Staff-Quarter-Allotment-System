<?php
session_start();  // Start the session at the beginning

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Initialize variables
$email = $password = "";
$emailError = $passwordError = $error = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname, $port);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Collect input data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // --- Email Validation ---
    if (empty($email)) {
        $emailError = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailError = "Invalid email format.";
    }

    // --- Password Validation ---
    if (empty($password)) {
        $passwordError = "Password is required.";
    } elseif (strlen($password) < 8) {
        $passwordError = "Password must be at least 8 characters long.";
    } elseif (!preg_match("/[A-Za-z]/", $password)) {
        $passwordError = "Password must contain at least one letter.";
    } elseif (!preg_match("/\d/", $password)) {
        $passwordError = "Password must contain at least one number.";
    } elseif (!preg_match("/[^A-Za-z\d]/", $password)) {
        $passwordError = "Password must contain at least one special character.";
    }

    // If no errors, proceed with database check
    if (empty($emailError) && empty($passwordError)) {
        // Prepare SQL statement to retrieve the hashed password
        $sql = "SELECT fac_id, name, email, password FROM faculty_login WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            // Fetch the user data
            $row = $result->fetch_assoc();
            $hashed_password = $row['password'];

            // Verify the entered password against the hashed password in the database
            if (password_verify($password, $hashed_password)) {
                // If password matches, set session variable
                $_SESSION['email'] = $email;  // Store the email in the session

                // Redirect to home page
                header("Location: home.php");
                exit();  // Important to exit after header redirect
            } else {
                $error = "Invalid email or password";  // Incorrect password
            }
        } else {
            $error = "Invalid email or password";  // No matching email
        }

        $stmt->close();
    }
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../admin/css/style.css">
    <title>SIOM | Faculty Login</title>
</head>
<body background="../faculty/src/wall11.jpg">
    <div class="wrapper" style="color: white;">
        <h2>Faculty Login</h2>
        <?php if (!empty($error)) {
            echo "<p style='color: red;'>$error</p>";
        } ?>
        <form id="loginForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">

            <!-- Email Field -->
            <div class="input-box">
                <input type="email" name="email" id="email" placeholder="Enter your email" required>
                <span id="emailError" class="error-message"></span>
            </div>

            <!-- Password Field -->
            <div class="input-box">
                <input type="password" name="password" id="password" placeholder="Enter password" required>
                <span id="passwordError" class="error-message"></span>
            </div>

            <!-- Submit Button -->
            <div class="input-box button">
                <input type="submit" value="Login Now">
            </div>

            <!-- Registration Link -->
            <div class="text">
                <h3>Don't have an account? <a href="../faculty/reg_emp.php">Register now</a></h3>
            </div>
        </form>
    </div>

    <script>
        // Get form fields
        const emailInput = document.getElementById("email");
        const passwordInput = document.getElementById("password");

        // Get error messages
        const emailError = document.getElementById("emailError");
        const passwordError = document.getElementById("passwordError");

        // Email validation pattern (basic email format)
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

        // Password validation pattern (at least 8 characters, one letter, one number, one symbol)
        const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/;

        // Real-time Email validation
        emailInput.addEventListener("input", function () {
            const emailValue = emailInput.value;

            if (!emailPattern.test(emailValue)) {
                emailError.textContent = "Please enter a valid email address.";
            } else {
                emailError.textContent = "";  // Clear error message when valid
            }
        });

        // Real-time Password validation
        passwordInput.addEventListener("input", function () {
            const passwordValue = passwordInput.value;

            if (!passwordPattern.test(passwordValue)) {
                passwordError.textContent = "Min length 8, 1 letter, 1 number and 1 symbol.";
            } else {
                passwordError.textContent = "";  // Clear error message when valid
            }
        });

        // Form submit validation (for both fields)
        document.getElementById("loginForm").addEventListener("submit", function (e) {
            const emailValue = emailInput.value;
            const passwordValue = passwordInput.value;

            let isValid = true;

            // Validate email
            if (!emailPattern.test(emailValue)) {
                emailError.textContent = "Please enter a valid email address.";
                isValid = false;
            }

            // Validate password
            if (!passwordPattern.test(passwordValue)) {
                passwordError.textContent = "Password must be at least 8 characters long, contain one letter, one number, and one symbol.";
                isValid = false;
            }

            // Prevent form submission if any field is invalid
            if (!isValid) {
                e.preventDefault();
            }
        });
    </script>

    <style>
        .input-box input {
            width: 100%;
            padding: 10px;
            font-size: 14px;
        }

        .input-box span {
            font-size: 0.9em;
            color: red;
        }

        .input-box button {
            font-size: 16px;
        }
    </style>
</body>
</html>
