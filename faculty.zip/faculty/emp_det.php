<?php
session_start(); // Start session to access session variables

// Check if the email session is set
if (!isset($_SESSION['email'])) {
    // If not, redirect to the login page
    header('Location: login_emp.php');  // Replace with the actual login page URL
    exit();  // Always call exit after redirect to prevent further code execution
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to create emp_det table
$sql = "
CREATE TABLE IF NOT EXISTS emp_det (
    emp_det_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_nature VARCHAR(100) NOT NULL,
    years_of_service INT NOT NULL,
    job_responsibilities VARCHAR(100) NOT NULL,
    fac_id_fk INT NOT NULL,
    CONSTRAINT fk_fac_emp FOREIGN KEY (fac_id_fk) REFERENCES faculty_login(fac_id)
)";

if ($conn->query($sql) !== TRUE) {
    echo "<script>alert('Error creating table: " . $conn->error . "');</script>";
}

// Check if the user is logged in3
if (!isset($_SESSION['email'])) {
    header("Location: login-emp.php");
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $employmentNature = $_POST['employmentNature'];
    $yearsOfService = $_POST['yearsOfService'];
    $jobResponsibilities = $_POST['jobResponsibilities'];

    // Prepare a SQL statement to get the fac_id based on the email stored in the session
    $fac_id_stmt = $conn->prepare("SELECT fac_id FROM faculty_login WHERE email = ?");
    $fac_id_stmt->bind_param("s", $email);
    $fac_id_stmt->execute();
    $fac_id_stmt->bind_result($fac_id_fk);
    $fac_id_stmt->fetch();
    $fac_id_stmt->close();

    if ($fac_id_fk) {
        // Insert employment details into the database
        $stmt = $conn->prepare("INSERT INTO emp_det (emp_nature, years_of_service, job_responsibilities, fac_id_fk) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $employmentNature, $yearsOfService, $jobResponsibilities, $fac_id_fk);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Employment details saved successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Faculty ID not found.";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employment Details</title>
    <link rel="stylesheet" href="../faculty/css/new_form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .error-message {
            color: red;
            font-size: 0.9em;
            display: none;
        }

        .invalid {
            border-color: red;
        }
    </style>

</head>

<body>
    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>
    <div style="height: 130px;">
        <!-- sagli kade paste karaycha aahe for height-->
    </div>
    <div class="progress-bar">
        <ul>
            <li class="active"><a href="personal_info.php">Personal <br> Information</a></li>
            <li><a href="fam_det.php">Family <br> Details</a></li>
            <li><a href="emp_det.php">Employment <br> Details</a></li>
            <li><a href="quat_pref.php">Quarter <br> Preference</a></li>
            <li><a href="docs.php">Upload <br> Documents</a></li>
        </ul>
        <div class="progress-line">
            <div class="filled-line"></div>
        </div>
    </div>

    <div class="container mt-5">
        <h2 class="mb-4">Employment Details Form</h2>
        <form id="familyDetailsForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
            <div class="mb-3">
                <label for="employmentNature" class="form-label">Employment Details</label>
                <select class="form-select" id="employmentNature" name="employmentNature" required>
                    <option value="">Select nature of employment</option>
                    <option value="Permanent">Permanent</option>
                    <option value="Contract">Contract</option>
                    <option value="Temporary">Temporary</option>

                </select>
            </div>

            <div class="form-group">
                <label for="name">Years of Service</label>
                <input type="text" id="yearsOfService" name="yearsOfService" required>
                <span class="error-message" id="yearsError">Please enter a valid number (0-50).</span>
            </div>
            <div class="form-group">
                <label for="designation">Current Job Responsibilities</label>
                <input type="text" id="jobResponsibilities" name="jobResponsibilities" required>
                <span class="error-message" id="jobError">Please describe your responsibilities (3 to 100 only characters).</span>
            </div>

            <button type="submit" class="btn btn-success me-2" onclick="saveForm()">Save</button>
            <button type="button" class="btn btn-primary" onclick="nextPage()">Next</button>
        </form>
    </div>
    <?php include_once('../faculty/footer.php'); ?>

    <script>
        // Function to set the active step and store it in localStorage
        function setActiveStep(index) {
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;
            if (index >= 0 && index < totalSteps) {
                localStorage.setItem('activeStep', index); // Store active step
                updateProgressBar(index);
            }
        }

        // Function to update progress bar based on active step
        function updateProgressBar(activeStep) {
            const steps = document.querySelectorAll('.progress-bar ul li');
            const progressLine = document.querySelector('.filled-line');

            // Update step classes
            steps.forEach((step, i) => {
                if (i <= activeStep) {
                    step.classList.add('active');
                } else {
                    step.classList.remove('active');
                }
            });

            // Update the width of the progress line
            const stepWidth = ((activeStep + 1) / steps.length) * 100;
            progressLine.style.width = stepWidth + '%';
        }

        // Function to handle "Next" button click
        function nextPage() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;

            if (activeStep < totalSteps - 1) {
                setActiveStep(activeStep + 1); // Move to the next step
                // Optionally navigate to the next form page based on the current active step
                if (activeStep === 0) {
                    window.location.href = 'fam_det.php';
                } else if (activeStep === 1) {
                    window.location.href = 'emp_det.php';
                } else if (activeStep === 2) {
                    window.location.href = 'quat_pref.php';
                } else if (activeStep === 3) {
                    window.location.href = 'docs.php';
                }
            }
        }

        // On page load, get the active step from localStorage and update the progress bar
        window.onload = function() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            updateProgressBar(activeStep);

            // Add click events to steps
            const steps = document.querySelectorAll('.progress-bar ul li');
            steps.forEach((step, i) => {
                step.addEventListener('click', () => setActiveStep(i));
            });
        }
        const yearsInput = document.getElementById('yearsOfService');
        const jobInput = document.getElementById('jobResponsibilities');
        const yearsError = document.getElementById('yearsError');
        const jobError = document.getElementById('jobError');

        // Validate years (must be a number between 0-50)
        function validateYears() {
            const val = yearsInput.value.trim();
            const isValid = /^\d+$/.test(val) && parseInt(val) >= 0 && parseInt(val) <= 50;
            yearsError.style.display = isValid ? 'none' : 'block';
            yearsInput.classList.toggle('invalid', !isValid);
            return isValid;
        }

        // Validate job responsibilities (min 3 chars)
        function validateJob() {
            const val = jobInput.value.trim();
            const regex = /^[A-Za-z\s]{3,100}$/;
            const isValid = regex.test(val);
            
            jobError.style.display = isValid ? 'none' : 'block';
            jobInput.classList.toggle('invalid', !isValid);
            
            return isValid;
        }

        // Attach event listeners
        yearsInput.addEventListener('input', validateYears);
        jobInput.addEventListener('input', validateJob);

        // On submit, prevent form if invalid
        document.getElementById('familyDetailsForm').addEventListener('submit', function (e) {
            if (!validateYears() || !validateJob()) {
                e.preventDefault();
            }
        });
    </script>

</body>

</html>