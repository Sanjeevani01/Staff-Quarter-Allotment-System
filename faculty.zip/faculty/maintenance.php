<?php
session_start(); // Start the session

// Check if the email is stored in the session
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Database connection details
$host = 'localhost';
$db = 'sqms';
$user = 'root';
$pass = '';
$port = 3308;

// Create a connection
$conn = new mysqli($host, $user, $pass, $db, $port);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch maintenance requests associated with the logged-in user
$sql = "SELECT * FROM maintenance WHERE email = ? ORDER BY request_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$maintenanceRequests = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Requests</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f5f5f5;
            color: #333;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .status {
            font-weight: bold;
        }

        .status.pending {
            color: #ff9800;
        }

        .status.completed {
            color: #4caf50;
        }

        .status.rejected {
            color: #f44336;
        }

        .no-data {
            padding: 20px;
            text-align: center;
            color: #666;
            font-style: italic;
        }

        .section-container {
            margin-top: 100px;
            margin-bottom: 20px;
        }

        .section-title {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
        }
    </style>
    <link rel="stylesheet" href="../faculty/css/form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>

    <div class="main-content">
        <div class="section-container">
            <h2 class="section-title">Maintenance Requests</h2>
            <div class="container">
                <table>
                    <tr>
                        <th>Maintenance ID</th>
                        <th>Campus</th>
                        <th>Block</th>
                        <th>Quarter Type</th>
                        <th>Flat No</th>
                        <th>Resident Name</th>
                        <th>Maintenance Reason</th>
                        <th>Request Date</th>
                        <th>Status</th>

                    </tr>
                    <?php
                    if ($maintenanceRequests->num_rows > 0) {
                        while ($row = $maintenanceRequests->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['maintenance_id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['campus_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['block_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['quarter_type']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['flat_no']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['resident_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['maintenance_reason']) . "</td>";
                            echo "<td>" . date('d-M-Y', strtotime($row['request_date'])) . "</td>";

                            // Status with color coding
                            $statusClass = strtolower($row['status']);
                            echo "<td class='status $statusClass'>" . htmlspecialchars($row['status']) . "</td>";



                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='11' class='no-data'>No maintenance requests found.</td></tr>";
                    }

                    // Close statement and connection
                    $stmt->close();
                    $conn->close();
                    ?>
                </table>
            </div>
        </div>
    </div>

    <?php include_once('../faculty/footer.php'); ?>
</body>

</html>