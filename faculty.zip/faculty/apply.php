<?php
session_start(); // Start the session

// Check if the email is stored in the session
if (!isset($_SESSION['email'])) {
    header("Location: login_emp.php"); // Redirect to login if not logged in
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Connect to the database
$conn = new mysqli("localhost", "root", "", "sqms",3308);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the fac_id from the faculty_login table using the email
$sql = "SELECT fac_id FROM faculty_login WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);  // Bind the email to the SQL query
$stmt->execute();
$result = $stmt->get_result();

// If the email exists, fetch the fac_id
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $fac_id = $row['fac_id'];  // Store the faculty's ID
} else {
    // If the faculty is not found (email does not exist), log out or handle error
    echo "User not found.";
    exit();
}

// Initialize a flag to check if all documents and details are present
// $all_submitted = true;

// Check for personal_info
$sql = "SELECT * FROM personal_info WHERE fac_id_fk = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $fac_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: personal_info.php");
    exit();
    // $all_submitted = false;
}

// Check for fam_det (family details)
$sql = "SELECT * FROM fam_det WHERE fac_id_fk = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $fac_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: fam_det.php");
    exit();

    // $all_submitted = false;
}

// Check for emp_det (employment details)
$sql = "SELECT * FROM emp_det WHERE fac_id_fk = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $fac_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: emp_det.php");
    exit();
    // $all_submitted = false;
}

// Check for quat_pref (qualification preferences)
$sql = "SELECT * FROM quat_perf WHERE fac_id_fk = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $fac_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: quat_pref.php");
    exit();
    // $all_submitted = false;
}

// Check for faculty_documents
$sql = "SELECT * FROM faculty_documents WHERE fac_id_fk = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $fac_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows == 0) {
    header("Location: docs.php");
    exit();
    // $all_submitted = false;
}


$stmt->close();
$conn->close();


// If not all data is submitted, redirect to the personal_info.php page
// if ($all_submitted) {
//     header("Location: aplay.php");
//     exit();
// }
// if (!$all_submitted) {
//     echo "Some sections are missing. Please check.<br>";
//     exit(); // comment this after debugging
// }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Documents Status</title>
    <style>
        body {
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* h1 {
            font-size: 24px;
            color: #333;
        }

        p {
            font-size: 18px;
            color: #666;
        } */

        a {
            color: #3498db;
            text-decoration: none;
        }

        .status-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: purple;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }

        .status-btn:hover {
            background-color: rgb(84, 1, 84);
            color: white; 
        }
    </style>
    <link rel="stylesheet" href="../faculty/css/progress.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>
    <div style="height: 130px;">
        <!-- sagli kade paste karaycha aahe for height-->
    </div>
    <div class="container">
        <h1>Document Submission Status</h1>

        <p>You have already submitted your documents and details.</p>
        <a href="status.php" class="status-btn">Check Your Application Status</a>
    </div>

    <?php include_once('../faculty/footer.php'); ?>
</body>

</html>