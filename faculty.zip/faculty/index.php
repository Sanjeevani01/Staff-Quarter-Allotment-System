<?php 
$host = "localhost";
$user = "root";
$password = "";
$port = 3308;

// Connect to MySQL server (no specific database yet)
$conn = new mysqli($host, $user, $password, "", $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS sqms";
if (!$conn->query($sql) === TRUE) {
    echo "<script>alert('Error creating database: " . addslashes($conn->error) . "');</script>";

}

$conn->close();

header("location:login_emp.php");
exit();
?>