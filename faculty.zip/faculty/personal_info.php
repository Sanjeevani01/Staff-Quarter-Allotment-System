<?php
session_start();  // Start the session to access session variables



// Check if the email session is set
if (!isset($_SESSION['email'])) {
    // If not, redirect to the login page
    header('Location: login_emp.php');  // Replace with the actual login page URL
    exit();  // Always call exit after redirect to prevent further code execution
}


// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
CREATE TABLE IF NOT EXISTS personal_info (
    emp_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(100),
    department VARCHAR(100),
    institute VARCHAR(100),
    date_of_joining DATE,
    phone_no VARCHAR(15),
    email VARCHAR(100),
    street_add TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    zip_code INT,
    fac_id_fk INT,
    principle_status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    admin_status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    CONSTRAINT fk_faculty FOREIGN KEY (fac_id_fk) REFERENCES faculty_login(fac_id)
)";



if ($conn->query($sql) !== TRUE) {
    echo "<script>alert('Error creating table: " . $conn->error . "');</script>";
}


// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the user is logged in and the email is set in session
    if (isset($_SESSION['email'])) {
        $email = $_SESSION['email'];  // Retrieve the email from session
    } else {
        // If not logged in, redirect to login page or show an error
        header("Location: login.php");
        exit;
    }

    // Collect form data
    $emp_id = $_POST['emp_id'];
    $name = $_POST['name'];
    $designation = $_POST['designation'];
    $dept = $_POST['dept'];
    $institute = $_POST['institute'];
    $date_of_joining = $_POST['date_of_joining'];
    $phone_no = $_POST['phone_no'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zip = $_POST['zip'];

    // Prepare a SQL statement to get the fac_id based on the session email
    $fac_id_stmt = $conn->prepare("SELECT fac_id FROM faculty_login WHERE email = ?");
    $fac_id_stmt->bind_param("s", $email);
    $fac_id_stmt->execute();
    $fac_id_stmt->bind_result($fac_id_fk);
    $fac_id_stmt->fetch();
    $fac_id_stmt->close();

    // Check if fac_id was found
    if ($fac_id_fk) {
        // Prepare an SQL statement for inserting into personal_info
        $sql = "INSERT INTO personal_info (emp_id, name, designation, department,institute, date_of_joining, phone_no, email, street_add, city, state, zip_code, fac_id_fk) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        // Create a prepared statement
        $stmt = $conn->prepare($sql);

        // Bind parameters to the prepared statement
        $stmt->bind_param("sssssssssssss", $emp_id, $name, $designation, $dept,$institute, $date_of_joining, $phone_no, $email, $street, $city, $state, $zip, $fac_id_fk);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Record inserted successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error: Faculty ID not found for the given email.";
    }
}

// Close connection
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Personal Information</title>
    <link rel="stylesheet" href="../faculty/css/new_form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        input:invalid {
            border-color: black;
        }
        .error-message {
            color: red;
            font-size: 0.85em;
        }
        input.valid {
            border-color: green;
        }

    </style>
</head>

<body>

    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>
    <div style="height: 130px;">
        <!-- sagli kade paste karaycha aahe for height-->
    </div>
    <div class="progress-bar">
        <ul>
            <li class="active"><a href="personal_info.php">Personal <br> Information</a></li>
            <li><a href="fam_det.php">Family<br>Details</a></li>
            <li><a href="emp_det.php">Employment <br> Details</a></li>
            <li><a href="quat_pref.php">Quarter <br> Preference</a></li>
            <li><a href="docs.php">Upload <br> Documents</a></li>
        </ul>
        <div class="progress-line">
            <div class="filled-line"></div>
        </div>
    </div>

    <div class="container">
        <h2>Personal Information</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" onsubmit="return validateForm()">
        <div class="form-group">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required>
            <small class="error-message" id="nameError"></small>
        </div>

        <div class="form-group">
            <label for="emp_id">Employee ID:</label>
            <input type="text" id="emp_id" name="emp_id" required>
            <small class="error-message" id="empIdError"></small>
        </div>

        <div class="form-group">
            <label for="designation">Designation:</label>
            <input type="text" id="designation" name="designation" required>
            <small class="error-message" id="designationError"></small>
        </div>

        <div class="form-group">
            <label for="dept">Department:</label>
            <input type="text" id="dept" name="dept" required>
            <small class="error-message" id="deptError"></small>
        </div>

        <div class="form-group">
            <label for="institute">Institute:</label>
            <input type="text" id="institute" name="institute" required>
            <small class="error-message" id="instituteError"></small>
        </div>

        <div class="form-group">
            <label for="date_of_joining">Date of Joining:</label>
            <input type="date" id="date_of_joining" name="date_of_joining" max="<?php echo date('Y-m-d'); ?>" required>
            <small class="error-message" id="dojError"></small>
        </div>

        <div class="form-group">
            <label for="phone_no">Phone Number:</label>
            <input type="tel" id="phone_no" name="phone_no" required>
            <small class="error-message" id="phoneError"></small>
        </div>

        <div class="form-group">
            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" required>
            <small class="error-message" id="emailError"></small>
        </div>

        <div class="form-group">
            <label for="street">Street Address:</label>
            <input type="text" id="street" name="street" required>
            <small class="error-message" id="streetError"></small>
        </div>

        <div class="form-group">
            <label for="state">State:</label>
            <input type="text" id="state" name="state" required>
            <small class="error-message" id="stateError"></small>
        </div>

        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" id="city" name="city" required>
            <small class="error-message" id="cityError"></small>
        </div>

        <div class="form-group">
            <label for="zip">Zip Code:</label>
            <input type="text" id="zip" name="zip" required>
            <small class="error-message" id="zipError"></small>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-primary" onclick="nextPage()">Next</button>
        </div>
    </form>

    </div>

    <?php include_once('../faculty/footer.php'); ?>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script> -->

    <script>
        // Function to set the active step and store it in localStorage
        function setActiveStep(index) {
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;
            if (index >= 0 && index < totalSteps) {
                localStorage.setItem('activeStep', index); // Store active step
                updateProgressBar(index);
            }
        }

        // Function to update progress bar based on active step
        function updateProgressBar(activeStep) {
            const steps = document.querySelectorAll('.progress-bar ul li');
            const progressLine = document.querySelector('.filled-line');

            // Update step classes
            steps.forEach((step, i) => {
                if (i <= activeStep) {
                    step.classList.add('active');
                } else {
                    step.classList.remove('active');
                }
            });

            // Update the width of the progress line
            const stepWidth = ((activeStep + 1) / steps.length) * 100;
            progressLine.style.width = stepWidth + '%';
        }

        // Function to handle "Next" button click
        function nextPage() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;

            if (activeStep < totalSteps - 1) {
                setActiveStep(activeStep + 1); // Move to the next step
                // Optionally navigate to the next form page based on the current active step
                if (activeStep === 0) {
                    window.location.href = 'fam_det.php';
                } else if (activeStep === 1) {
                    window.location.href = 'emp_det.php';
                } else if (activeStep === 2) {
                    window.location.href = 'quat_pref.php';
                } else if (activeStep === 3) {
                    window.location.href = 'docs.php';
                }
            }
        }

        // On page load, get the active step from localStorage and update the progress bar
        window.onload = function() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            updateProgressBar(activeStep);

            // Add click events to steps
            const steps = document.querySelectorAll('.progress-bar ul li');
            steps.forEach((step, i) => {
                step.addEventListener('click', () => setActiveStep(i));
            });
        }
        function validateForm() {
            const email = document.getElementById("email").value.trim();
            const sessionEmail = "<?php echo $_SESSION['email']; ?>";

            if (email !== sessionEmail) {
                alert("Email must match your registered email: " + sessionEmail);
                return false;
            }

            const doj = document.getElementById("date_of_joining").value;
            const today = new Date().toISOString().split('T')[0];
            if (doj > today) {
                alert("Date of Joining cannot be in the future.");
                return false;
            }

            return true; // All good
        }
        
        document.addEventListener("DOMContentLoaded", () => {
            const fields = {
                name: {
                    element: document.getElementById('name'),
                    errorId: 'nameError',
                    regex: /^[A-Za-z\s]{3,}$/,
                    message: "Name must be at least 3 characters and only letters/spaces."
                },
                emp_id: {
                    element: document.getElementById('emp_id'),
                    errorId: 'empIdError',
                    regex: /^[A-Za-z0-9]{3,}$/,
                    message: "Employee ID must be at least 3 alphanumeric characters."
                },
                designation: {
                    element: document.getElementById('designation'),
                    errorId: 'designationError',
                    regex: /^[A-Za-z\s]{2,}$/,
                    message: "Designation must be at least 2 letters."
                },
                dept: {
                    element: document.getElementById('dept'),
                    errorId: 'deptError',
                    regex: /^[A-Za-z\s]{2,}$/,
                    message: "Department must contain only letters."
                },
                institute: {
                    element: document.getElementById('institute'),
                    errorId: 'instituteError',
                    regex: /^[A-Za-z\s]{2,}$/,
                    message: "Institute name must be valid."
                },
                phone_no: {
                    element: document.getElementById('phone_no'),
                    errorId: 'phoneError',
                    regex: /^[0-9]{10}$/,
                    message: "Enter a valid 10-digit phone number."
                },
                email: {
                    element: document.getElementById('email'),
                    errorId: 'emailError',
                    regex: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                    message: "Enter a valid email address."
                },
                street: {
                    element: document.getElementById('street'),
                    errorId: 'streetError',
                    regex: /.+/,
                    message: "Street address cannot be empty."
                },
                state: {
                    element: document.getElementById('state'),
                    errorId: 'stateError',
                    regex: /^[A-Za-z\s]{2,}$/,
                    message: "State must contain only letters."
                },
                city: {
                    element: document.getElementById('city'),
                    errorId: 'cityError',
                    regex: /^[A-Za-z\s]{2,}$/,
                    message: "City must contain only letters."
                },
                zip: {
                    element: document.getElementById('zip'),
                    errorId: 'zipError',
                    regex: /^[0-9]{5,6}$/,
                    message: "Zip code must be 5 or 6 digits."
                }
            };

            for (let key in fields) {
                const field = fields[key];
                field.element.addEventListener('input', () => {
                    const value = field.element.value.trim();
                    const errorElem = document.getElementById(field.errorId);
                    if (!field.regex.test(value)) {
                        errorElem.textContent = field.message;
                        field.element.classList.remove("valid");
                    } else {
                        errorElem.textContent = "";
                        field.element.classList.add("valid");
                    }
                });
            }

            // Final validation before submission
            document.querySelector('form').addEventListener('submit', (e) => {
                let isValid = true;
                for (let key in fields) {
                    const field = fields[key];
                    const value = field.element.value.trim();
                    const errorElem = document.getElementById(field.errorId);
                    if (!field.regex.test(value)) {
                        errorElem.textContent = field.message;
                        field.element.classList.remove("valid");
                        isValid = false;
                    } else {
                        errorElem.textContent = "";
                        field.element.classList.add("valid");
                    }
                }
                if (!isValid) {
                    e.preventDefault();
                    alert("Please correct the errors in the form.");
                }
            });
        });



    </script>



</body>

</html>