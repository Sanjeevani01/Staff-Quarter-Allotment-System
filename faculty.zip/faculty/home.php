<?php
session_start();

// Check if the email session is set
if (!isset($_SESSION['email'])) {
    // If not, redirect to the login page
    header('Location: login_emp.php');  // Replace with the actual login page URL
    exit();  // Always call exit after redirect to prevent further code execution
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SQMS | Home Page</title>
  <link rel="stylesheet" href="../faculty/css/form.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
    /* Reset some default styles */
    body,
    html {
      margin: 0;
      padding: 0;
      width: 100%;
      background-color: whitesmoke;
      overflow-x: hidden;
    }

    /* Slideshow Wrapper */
    .slideshow-wrapper {
      width: 100vw;
      position: relative;
      left: 50%;
      right: 50%;
      margin-left: -50vw;
      margin-right: -50vw;
    }

    /* Slideshow Styles */
    .slideshow {
      position: relative;
      height: 700px;
      overflow: hidden;
      width: 100%;
    }

    .slideshow-container {
      position: absolute;
      width: 300%;
      /* 100% for each of the 3 images */
      height: 150%;
      display: flex;
      animation: slide 12s infinite;
    }

    .slideshow-image {
      flex: 1;
      background-size: cover;
      background-position: center;
      transition: opacity 1s ease-in-out;
    }

    /* Keyframes for Slideshow */
    @keyframes slide {
      0% {
        transform: translateX(0);
      }

      33.33% {
        transform: translateX(-33.33%);
      }

      66.66% {
        transform: translateX(-66.66%);
      }

      100% {
        transform: translateX(0);
      }
    }

    /* Media query for responsiveness */
    @media screen and (max-width: 768px) {
      .slideshow {
        height: 300px;
        /* Adjust height for smaller screens */
      }
    }

    /* Existing styles remain the same */

    /* New styles for the text overlay */
    .slideshow {
      position: relative;
      height: 710px;
      overflow: hidden;
      width: 100%;
    }

    .slideshow-text {
      position: absolute;
      top: 120px;
      /* Adjust this value to move the text up or down */
      left: 0;
      width: 100%;
      padding: 20px;
      text-align: center;
      color: rgba(0, 0, 0, 0.5);
      /* Adjust text color as needed */
      z-index: 10;
      /* Ensures text appears above the slideshow */
    }

    .slideshow-text h1 {
      font-size: 2.5em;
      margin-bottom: 10px;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
      /* Adds a shadow for better readability */
    }

    .slideshow-text p {
      font-size: 1.2em;
      text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
    }

    /* Media query for responsiveness */
    @media screen and (max-width: 768px) {
      .slideshow {
        height: 300px;
        /* Adjust height for smaller screens */
      }

      .slideshow-text h1 {
        font-size: 1.8em;
      }

      .slideshow-text p {
        font-size: 1em;
      }
    }
  </style>
</head>

<body>
  <?php include_once('../faculty/header.php'); ?>
  <?php include_once('../faculty/emp_left_nav.php'); ?>
  <!-- Slideshow Section -->
  <section class="slideshow-wrapper">
    <div class="slideshow">
      <div class="slideshow-container">
        <div class="slideshow-image" style="background-image: url('../faculty/src/wall11.jpg');"></div>
        <div class="slideshow-image" style="background-image: url('../faculty/src/wall12.jpg');"></div>
        <div class="slideshow-image" style="background-image: url('../faculty/src/wall13.jpg');"></div>
      </div>
      <div class="slideshow-text">
        <h1><b>Sinhgad Institutes</b></h1>
        <h3><b>Quarter Allotment Portal</b></h3>
      </div>
    </div>
  </section>


  <?php include_once('../faculty/footer.php'); ?>
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script> -->

  <script>
    // Function to set the active step and store it in localStorage
    function setActiveStep(index) {
      localStorage.setItem('activeStep', index); // Store active step
      updateProgressBar(index);
    }

    // Function to update progress bar based on active step
    function updateProgressBar(activeStep) {
      const steps = document.querySelectorAll('.progress-bar ul li');
      const progressLine = document.querySelector('.filled-line');
    }

    // Function to update progress bar based on active step
    function updateProgressBar(activeStep) {
      const steps = document.querySelectorAll('.progress-bar ul li');
      const progressLine = document.querySelector('.filled-line');

      // Remove 'active' class from all steps
      steps.forEach((step, i) => {
        if (i <= activeStep) {
          step.classList.add('active'); // Add 'active' class to all steps up to the active one
        } else {
          step.classList.remove('active'); // Remove 'active' class from the rest
        }
      });

      // Update the width of the progress line based on the active step
      const stepWidth = ((activeStep + 1) / steps.length) * 100;
      progressLine.style.width = stepWidth + '%';
    }

    // On page load, get the active step from localStorage and update the progress bar
    window.onload = function() {
      const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
      updateProgressBar(activeStep);
    }

    // Add click events to steps
    const steps = document.querySelectorAll('.progress-bar ul li');
    steps.forEach((step, i) => {
      step.addEventListener('click', () => setActiveStep(i)); // Store the index when a step is clicked
    });


    function nextPage() {
      window.location.href = 'fam_det.php';

    }
  </script>


</body>

</html>