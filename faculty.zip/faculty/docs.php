<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start(); // Start session to access session variables

// Check if the email session is set
if (!isset($_SESSION['email'])) {
    // If not, redirect to the login page
    header('Location: login_emp.php');  // Replace with the actual login page URL
    exit();  // Always call exit after redirect to prevent further code execution
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
CREATE TABLE faculty_documents (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    fac_id_fk INT(11) NOT NULL,
    proof_of_employment VARCHAR(255) DEFAULT NULL,
    identity_proof VARCHAR(255) DEFAULT NULL,
    proof_of_family VARCHAR(255) DEFAULT NULL,
    medical_certificates VARCHAR(255) DEFAULT NULL,
    other_documents VARCHAR(255) DEFAULT NULL,
    declaration_form VARCHAR(255) DEFAULT NULL,
    CONSTRAINT fk_faculty_docs FOREIGN KEY (fac_id_fk) REFERENCES faculty_login(fac_id)
        
) 
";

if ($conn->query($sql) !== TRUE) {
    echo "<script>alert('Error creating table: " . addslashes($conn->error) . "');</script>";
}


// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login_emp.php");
    exit();
}

// Get the email from the session
$email = $_SESSION['email'];

// Prepare directory to store uploads
$uploadDir = "C:\\xampp\\htdocs\\sqms\\faculty\\uploads\\";

// Create upload directory if it doesn't exist
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Array to store upload file paths
    $fileNames = [];

    // Define allowed file types
    $allowedFileTypes = ['jpg', 'jpeg', 'png', 'pdf'];

    // File fields to process
    $fileFields = ['proofOfEmployment', 'identityProof', 'proofOfFamilyMembers', 'medicalCertificates', 'otherDocuments', 'declarationForm'];

    // Loop through each file field and handle the upload
    foreach ($fileFields as $field) {
        if (isset($_FILES[$field]) && $_FILES[$field]['error'] !== UPLOAD_ERR_NO_FILE) {  // Check if the file field exists and if no file is uploaded
            if ($_FILES[$field]['error'] === UPLOAD_ERR_OK) {
                $fileName = $_FILES[$field]['name'];
                $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                $fileBaseName = pathinfo($fileName, PATHINFO_FILENAME);

                // Validate file type
                if (in_array($fileExtension, $allowedFileTypes)) {
                    // Use the email as part of the filename to avoid conflicts

                    $newFileName = $email . "_" . $fileBaseName . '.' . $fileExtension;
                    $fileDestination = $uploadDir . $newFileName;

                    // Move uploaded file to target directory
                    if (move_uploaded_file($_FILES[$field]['tmp_name'], $fileDestination)) {
                        $fileNames[$field] = $newFileName; // Store the new filename
                    } else {
                        echo "Error moving uploaded file: $fileName<br>";
                    }
                } else {
                    echo "Invalid file type for: $fileName<br>";
                }
            } else {
                echo "Error with file upload for: $fileName. Error code: " . $_FILES[$field]['error'] . "<br>";
            }
        } else {
            // Field not present or no file uploaded for this field, set as null
            $fileNames[$field] = null;
        }
    }

    // Prepare a SQL statement to get the fac_id based on the email stored in the session
    $fac_id_stmt = $conn->prepare("SELECT fac_id FROM faculty_login WHERE email = ?");
    $fac_id_stmt->bind_param("s", $email);
    $fac_id_stmt->execute();
    $fac_id_stmt->bind_result($fac_id_fk);
    $fac_id_stmt->fetch();
    $fac_id_stmt->close();

    if ($fac_id_fk) {
        // Extract the file names from the $fileNames array
        $proofOfEmployment = $fileNames['proofOfEmployment'];
        $identityProof = $fileNames['identityProof'];
        $proofOfFamilyMembers = $fileNames['proofOfFamilyMembers'];
        $medicalCertificates = $fileNames['medicalCertificates'];
        $otherDocuments = $fileNames['otherDocuments'];
        $declarationForm = $fileNames['declarationForm'];

        // Prepare a SQL insert statement to store file names
        $stmt = $conn->prepare("
            INSERT INTO faculty_documents 
            (fac_id_fk, proof_of_employment, identity_proof, proof_of_family, medical_certificates, other_documents, declaration_form) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        // Check if the statement was prepared correctly
        if ($stmt === false) {
            die('MySQL prepare error: ' . $conn->error);
        }

        // Bind the parameters
        $stmt->bind_param(
            "issssss",
            $fac_id_fk,
            $proofOfEmployment,
            $identityProof,
            $proofOfFamilyMembers,
            $medicalCertificates,
            $otherDocuments,
            $declarationForm
        );

        // Execute the statement and check for errors
        if ($stmt->execute()) {
            echo "Documents uploaded successfully!<br>";
        } else {
            echo "Error executing statement: " . $stmt->error . "<br>";
        }

        $stmt->close();
    } else {
        echo "Faculty ID not found.<br>";
    }
}

// Close connection
$conn->close();
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="./src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Documents</title>
    <link rel="stylesheet" href="../faculty/css/new_form.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <?php include_once('../faculty/header.php'); ?>
    <?php include_once('../faculty/emp_left_nav.php'); ?>
    <div style="height: 130px;">
        <!-- sagli kade paste karaycha aahe for height-->
    </div>
    <div class="progress-bar">
        <ul>
            <li class="active"><a href="personal_info.php">Personal <br> Information</a></li>
            <li><a href="fam_det.php">Family <br> Details</a></li>
            <li><a href="emp_det.php">Employment <br> Details</a></li>
            <li><a href="quat_pref.php">Quarter <br> Preference</a></li>
            <li><a href="docs.php">Upload <br> Documents</a></li>
        </ul>
        <div class="progress-line">
            <div class="filled-line"></div>
        </div>
    </div>

    <div class="container">
        <h2>Document Upload Form</h2>
        <form id="documentUploadForm" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" enctype="multipart/form-data">
            <!-- Proof of Employment -->
            <div class="mb-3">
                <label for="proofOfEmployment" class="form-label">Proof of Employment</label>
                <input type="file" class="form-control" id="proofOfEmployment" name="proofOfEmployment" accept=".jpg,.png,.pdf" required>
                <!-- <div class="form-text">Accepted formats: JPG, PNG, PDF</div> -->
            </div>

            <!-- Identity Proof -->
            <div class="mb-3">
                <label for="identityProof" class="form-label">Identity Proof (e.g., Passport, Aadhar Card)</label>
                <input type="file" class="form-control" id="identityProof" name="identityProof" accept=".jpg,.png,.pdf" required>
                <!-- <div class="form-text">Accepted formats: JPG, PNG, PDF</div> -->
            </div>

            <!-- Proof of Family Members -->
            <div class="mb-3">
                <label for="proofOfFamilyMembers" class="form-label">Proof of Family Members (e.g., Marriage Certificate, Birth Certificates)</label>
                <input type="file" class="form-control" id="proofOfFamilyMembers" name="proofOfFamilyMembers" accept=".jpg,.png,.pdf" required>
                <!-- <div class="form-text">Accepted formats: JPG, PNG, PDF</div> -->
            </div>

            <!-- Medical Certificates -->
            <div class="mb-3">
                <label for="medicalCertificates" class="form-label">Medical Certificates (if applicable)</label>
                <input type="file" class="form-control" id="medicalCertificates" name="medicalCertificates" accept=".jpg,.png,.pdf">
                <!-- <div class="form-text">Accepted formats: JPG, PNG, PDF</div> -->
            </div>

            <!-- Other Relevant Documents -->
            <div class="mb-3">
                <label for="otherDocuments" class="form-label">Any Other Relevant Documents</label>
                <input type="file" class="form-control" id="otherDocuments" name="otherDocuments" accept=".jpg,.png,.pdf">
                <!-- <div class="form-text">Accepted formats: JPG, PNG, PDF</div> -->
            </div>

            <!-- Declaration form -->
            <div class="mb-3">
                <label for="otherDocuments" class="form-label">Declaration form</label>
                <input type="file" class="form-control" id="declarationForm" name="declarationForm" accept=".jpg,.png,.pdf">
                <!-- <div class="form-text">Accepted formats: JPG, PNG, PDF</div> -->
            </div>

            <!-- Buttons -->
            <div class="btn-container">
                <button type="submit" class="btn btn-success">Submit Form</button>
                <!-- <button type="button" class="btn btn-primary" onclick="nextPage()">Next</button> -->
            </div>
        </form>
    </div>

    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script> -->


    <?php include_once('../faculty/footer.php'); ?>
    <script>
        // Function to set the active step and store it in localStorage
        function setActiveStep(index) {
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;
            if (index >= 0 && index < totalSteps) {
                localStorage.setItem('activeStep', index); // Store active step
                updateProgressBar(index);
            }
        }

        // Function to update progress bar based on active step
        function updateProgressBar(activeStep) {
            const steps = document.querySelectorAll('.progress-bar ul li');
            const progressLine = document.querySelector('.filled-line');

            // Update step classes
            steps.forEach((step, i) => {
                if (i <= activeStep) {
                    step.classList.add('active');
                } else {
                    step.classList.remove('active');
                }
            });

            // Update the width of the progress line
            const stepWidth = ((activeStep + 1) / steps.length) * 100;
            progressLine.style.width = stepWidth + '%';
        }

        // Function to handle "Next" button click
        function nextPage() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            const totalSteps = document.querySelectorAll('.progress-bar ul li').length;

            if (activeStep < totalSteps - 1) {
                setActiveStep(activeStep + 1); // Move to the next step
                // Optionally navigate to the next form page based on the current active step
                if (activeStep === 0) {
                    window.location.href = 'fam_det.php';
                } else if (activeStep === 1) {
                    window.location.href = 'emp_det.php';
                } else if (activeStep === 2) {
                    window.location.href = 'quat_pref.php';
                } else if (activeStep === 3) {
                    window.location.href = 'docs.php';
                }
            }
        }

        // On page load, get the active step from localStorage and update the progress bar
        window.onload = function() {
            const activeStep = parseInt(localStorage.getItem('activeStep')) || 0;
            updateProgressBar(activeStep);

            // Add click events to steps
            const steps = document.querySelectorAll('.progress-bar ul li');
            steps.forEach((step, i) => {
                step.addEventListener('click', () => setActiveStep(i));
            });
        }
    </script>



</body>

</html>