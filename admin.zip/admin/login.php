<?php
session_start();

// DB params
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Initialize
$email = $role = $password = "";
$error = "";

// If form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $password = $_POST['password'];

    // Server-side validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (empty($role)) {
        $error = "Please select a role.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        $sql = "SELECT user_id, name, email, role, password FROM admin WHERE email = ? AND role = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $role);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows == 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $_SESSION['role'] = $role;
                if ($role == 'Principle') {
                    header("Location: principle/dashboard.php");
                } elseif ($role == 'Admin') {
                    header("Location: admin_l1/dashboard.php");
                } else {
                    header("Location: super_admin/form.php");
                }
                exit();
            } else {
                $error = "Incorrect password.";
            }
        } else {
            $error = "No user found with that email and role.";
        }
        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../faculty/src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../admin/css/style.css">
    <title>SIOM | Login</title>
    <style>
        .error-msg {
            color: red;
            font-size: 0.70em;
            margin-top: 1px;
        }
        .input-box {
            position: relative;
        }
    </style>
</head>
<body background="../faculty/src/wall11.jpg">
    <div class="wrapper">
        <h2>Admin Login</h2>
        <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?>
        <form id="loginForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="input-box">
                <select name="role" id="role" required>
                    <option value="" disabled selected>Select a role</option>
                    <option value="Principle">Principle</option>
                    <option value="Admin">Admin</option>
                    <option value="Super Admin">Super Admin</option>
                </select>
                <div id="roleError" class="error-msg"></div>
            </div>
            <div class="input-box">
                <input type="email" name="email" id="email" placeholder="Enter your email" required>
                <div id="emailError" class="error-msg"></div>
            </div>
            <div class="input-box">
                <input type="password" name="password" id="password" placeholder="Enter password" required>
                <span id="passwordHelp" style="font-size: 12px; color: red;"></span>
            </div>

            <div class="input-box button">
                <input type="submit" value="Login Now">
            </div>
            <div class="text">
                <h3>Don't have an account? <a href="../admin/registration.php">Register now</a></h3>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const form = document.getElementById("loginForm");
            const emailInput = document.querySelector('input[name="email"]');
            const passwordInput = document.querySelector('input[name="password"]');
            const roleInput = document.querySelector('select[name="role"]');
            const passwordHelp = document.getElementById("passwordHelp");

            // Create email help text span
            const emailHelp = document.createElement("span");
            emailHelp.style.fontSize = "12px";
            emailHelp.style.color = "red";
            emailInput.parentNode.appendChild(emailHelp);

            const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Real-time email validation
            emailInput.addEventListener("input", function () {
                const email = emailInput.value.trim();
                if (!emailRegex.test(email)) {
                    emailHelp.textContent = "Invalid email format.";
                } else {
                    emailHelp.textContent = "";
                }
            });

            // Real-time password validation
            passwordInput.addEventListener("input", function () {
                const password = passwordInput.value;
                if (!passwordRegex.test(password)) {
                    passwordHelp.textContent = "Min 8 chars, 1 letter, 1 number & 1 symbol required.";
                } else {
                    passwordHelp.textContent = "";
                }
            });

            // Form submission validation
            form.addEventListener("submit", function (e) {
                const email = emailInput.value.trim();
                const password = passwordInput.value.trim();
                const role = roleInput.value;

                if (!email || !password || !role) {
                    alert("All fields are required.");
                    e.preventDefault();
                    return;
                }

                if (!emailRegex.test(email)) {
                    alert("Please enter a valid email.");
                    e.preventDefault();
                    return;
                }

                if (!passwordRegex.test(password)) {
                    alert("Password must be at least 8 characters and include a letter, number, and symbol.");
                    e.preventDefault();
                }
            });
        });
        </script>


</body>
</html>
