<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
CREATE TABLE users (
    user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(64) NOT NULL UNIQUE,
    name VARCHAR(64) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(32) NOT NULL UNIQUE
) 
";

// if ($conn->query($sql) !== TRUE) {
//     echo "<script>alert('Error creating table: " . addslashes($conn->error) . "');</script>";
// }


// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $password = $_POST['password'];

    // Server-side validation
    $errors = [];

    if (!preg_match("/^[a-zA-Z\s]{2,50}$/", $name)) {
        $errors[] = "Name must contain only letters and spaces (2–50 characters).";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (!preg_match("/^(?=.*[A-Za-z])(?=.*\d)(?=.*[^A-Za-z\d])[A-Za-z\d\S]{8,}$/", $password)) {
        $errors[] = "Password must be at least 8 characters and include at least one letter, one number, and one special character.";
    }

    if (empty($role)) {
        $errors[] = "Role is required.";
    }

    if (empty($errors)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and execute SQL
        $sql = "INSERT INTO admin (name, email, role, password) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $name, $email, $role, $hashed_password);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href = '../admin/login.php';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        foreach ($errors as $error) {
            echo "<script>alert('$error');</script>";
        }
    }
}

$conn->close();
?>

<!-- HTML Start -->
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../faculty/src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../admin/css/style.css">
    <title>SIOM | Admin Registration</title>
    <style>
        .error {
            color: red;
            font-size: 0.70em;
            margin-top: 2px;
            display: block;
        }
    </style>
</head>
<body background="../faculty/src/wall11.jpg">
    <div class="wrapper">
        <h2>Admin Registration</h2>
        <form id="registrationForm" method="post">
            <div class="input-box">
                <input type="text" placeholder="Enter your name" name="name" id="name" required>
                <span class="error" id="nameError"></span>
            </div>
            <div class="input-box">
                <input type="email" placeholder="Enter your email" name="email" id="email" required>
                <span class="error" id="emailError"></span>
            </div>
            <div class="input-box">
                <input type="password" placeholder="Create password" name="password" id="password" required>
                <span class="error" id="passwordError"></span>
            </div>
            <div class="input-box">
                <select name="role" required>
                    <option value="" disabled selected>Select a role</option>
                    <option value="Principle">Principle</option>
                    <option value="Admin">Admin</option>
                    <option value="Super Admin">Super Admin</option>
                </select>
            </div>
            <div class="policy">
                <input type="checkbox" id="termsCheckbox">
                <h3>I accept all terms & conditions</h3>
            </div>
            <div class="input-box button">
                <input type="submit" value="Register Now">
            </div>
            <div class="text">
                <h3>Already have an account? <a href="../admin/login.php">Login now</a></h3>
            </div>
        </form>
    </div>
</body>

<!-- JavaScript Validation -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");

    nameInput.addEventListener("input", function () {
        const name = nameInput.value.trim();
        const nameError = document.getElementById("nameError");
        if (!/^[a-zA-Z\s]{2,50}$/.test(name)) {
            nameError.textContent = "Only letters and spaces allowed (2–50 characters).";
        } else {
            nameError.textContent = "";
        }
    });

    emailInput.addEventListener("input", function () {
        const email = emailInput.value.trim();
        const emailError = document.getElementById("emailError");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            emailError.textContent = "Enter a valid email address.";
        } else {
            emailError.textContent = "";
        }
    });

    passwordInput.addEventListener("input", function () {
        const password = passwordInput.value;
        const passwordError = document.getElementById("passwordError");
        if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[^A-Za-z\d])[A-Za-z\d\S]{8,}$/.test(password)) {
            passwordError.textContent = "Minimum 8 characters, 1 letter, 1 number, 1 symbol.";
        } else {
            passwordError.textContent = "";
        }
    });

    document.getElementById("registrationForm").addEventListener("submit", function (e) {
        const name = nameInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();
        const role = document.querySelector('select[name="role"]').value;
        const terms = document.getElementById("termsCheckbox").checked;

        let formValid = true;

        if (!terms) {
            alert("You must accept the terms & conditions.");
            formValid = false;
        }

        if (!/^[a-zA-Z\s]{2,50}$/.test(name)) {
            document.getElementById("nameError").textContent = "Only letters and spaces allowed (2–50 characters).";
            formValid = false;
        }

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            document.getElementById("emailError").textContent = "Enter a valid email address.";
            formValid = false;
        }

        if (!/^(?=.*[A-Za-z])(?=.*\d)(?=.*[^A-Za-z\d])[A-Za-z\d\S]{8,}$/.test(password)) {
            document.getElementById("passwordError").textContent = "Minimum 8 characters, 1 letter, 1 number, 1 symbol.";
            formValid = false;
        }

        if (!role) {
            alert("Please select a role.");
            formValid = false;
        }

        if (!formValid) {
            e.preventDefault();
        }
    });
});
</script>
</html>
