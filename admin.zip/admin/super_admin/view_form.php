<?php

    // Start the session at the very top
        session_start();
        // Check if the email is stored in the session
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super Admin') {
            header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in
        exit();
}

// Database connection
$servername = "localhost";
$username = "root"; // Database username
$password = ""; // Database password
$dbname = "sqms"; // Your database name
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle approve/decline actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'] === 'approve' ? 'Approved' : 'Declined';

    // Update the status of the user in the `personal_info` table
    $sql = "UPDATE personal_info SET status='$action' WHERE emp_id=$id";
    if ($conn->query($sql) === TRUE) {
        // Successful update
        echo "User status updated successfully.";
        // Redirect to pending_form.php after successful update
        header("Location: pending_form.php"); // Correct syntax
        exit(); // Ensure no further code runs after the header redirect
    } else {
        // Error updating the record
        echo "Error updating record: " . $conn->error;
        // Redirect back to view_form.php in case of an error
        header("Location: view_form.php"); // Correct syntax
        exit(); // Ensure no further code runs after the header redirect
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard - SQMS</title>
    <style>
        :root {
            --primary-color: purple;
            --secondary-color: purple;
            --background-color: #f0f0f0;
            --white: #ffffff;
            --gray: #333333;
            --light-gray: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: var(--background-color);
            color: var(--gray);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

    

        .main-content {
            flex-grow: 1;
            padding: 1rem;
            overflow-y: auto;
        }

        .dashboard-section {
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        h3 {
            color: var(--secondary-color);
            margin-top: 2rem;
            margin-bottom: 1rem;
        }

        .form-grid1 {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .form-group1 {
            background-color: var(--light-gray);
            padding: 1rem;
            border-radius: 4px;
        }

        .form-group1 label {
            font-weight: bold;
            margin-bottom: 0.5rem;
            display: block;
        }

        .form-group1 span {
            display: block;
            margin-top: 0.5rem;
            background-color: var(--white);
            padding: 0.5rem;
            border-radius: 4px;
        }

        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: var(--white);
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            cursor: pointer;
            border: none;
        }

        .btn:hover {
            background-color: var(--secondary-color);
        }

        .btn-container {
            margin-top: 2rem;
            display: flex;
            justify-content: center;
            /* Change this from flex-end to center */
            gap: 10px;
        }
    </style>
</head>

<body>
<?php include_once('../super_admin/sidebar.php'); ?>

    <main class="main-content">
        <section class="dashboard-section">
            <h2>View Form Details</h2>
            <?php
            // Check if an ID is provided
            if (isset($_GET['id'])) {
                $fac_id_fk = $_GET['id'];

                // Replace with your database connection details
                $conn = new mysqli("localhost", "root", "", "sqms", 3308);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch data from personal_info table
                $sql_personal = "SELECT * FROM personal_info WHERE fac_id_fk = ?";
                $stmt_personal = $conn->prepare($sql_personal);
                $stmt_personal->bind_param("s", $fac_id_fk);
                $stmt_personal->execute();
                $result_personal = $stmt_personal->get_result();
                $personal_info = $result_personal->fetch_assoc();

                // Fetch data from fam_det table
                $sql_fam = "SELECT * FROM fam_det WHERE fac_id_fk = ?";
                $stmt_fam = $conn->prepare($sql_fam);
                $stmt_fam->bind_param("s", $fac_id_fk);
                $stmt_fam->execute();
                $result_fam = $stmt_fam->get_result();
                $fam_det = $result_fam->fetch_assoc();

                //Fetch family members
                $family_members = [];

                if ($fam_det) {
                    $fam_det_id = $fam_det['fam_det_id']; // assuming 'id' is primary key of fam_det
                    $sql_family_members = "SELECT * FROM family_members WHERE fam_det_id_fk = ?";
                    $stmt_family = $conn->prepare($sql_family_members);
                    $stmt_family->bind_param("i", $fam_det_id);
                    $stmt_family->execute();
                    $result_family = $stmt_family->get_result();

                    while ($row = $result_family->fetch_assoc()) {
                        $family_members[] = $row;
                    }
                }

                // Fetch data from emp_det table
                $sql_emp = "SELECT * FROM emp_det WHERE fac_id_fk = ?";
                $stmt_emp = $conn->prepare($sql_emp);
                $stmt_emp->bind_param("s", $fac_id_fk);
                $stmt_emp->execute();
                $result_emp = $stmt_emp->get_result();
                $emp_det = $result_emp->fetch_assoc();

                // Fetch data from quat_perf table
                $sql_quat = "SELECT * FROM quat_perf WHERE fac_id_fk = ?";
                $stmt_quat = $conn->prepare($sql_quat);
                $stmt_quat->bind_param("s", $fac_id_fk);
                $stmt_quat->execute();
                $result_quat = $stmt_quat->get_result();
                $quat_pref = $result_quat->fetch_assoc();

                // Fetch data from faculty_documents table
                $sql_docs = "SELECT * FROM faculty_documents WHERE fac_id_fk = ?";
                $stmt_docs = $conn->prepare($sql_docs);
                $stmt_docs->bind_param("s", $fac_id_fk);
                $stmt_docs->execute();
                $result_docs = $stmt_docs->get_result();
                $faculty_documents = $result_docs->fetch_assoc();

                if ($personal_info) {
                    echo "<h3>Personal Information</h3>";
                    echo "<div class='form-grid1'>";

                    // Personal Information Section

                    echo "<div class='form-group1'><label>Name:</label><span>" . htmlspecialchars($personal_info['name']) . "</span></div>";
                    echo "<div class='form-group1'><label>Designation:</label><span>" . htmlspecialchars($personal_info['designation']) . "</span></div>";
                    echo "<div class='form-group1'><label>Department:</label><span>" . htmlspecialchars($personal_info['department']) . "</span></div>";
                    echo "<div class='form-group1'><label>Date of Joining:</label><span>" . htmlspecialchars($personal_info['date_of_joining']) . "</span></div>";
                    echo "<div class='form-group1'><label>Phone No:</label><span>" . htmlspecialchars($personal_info['phone_no']) . "</span></div>";
                    echo "<div class='form-group1'><label>Email:</label><span>" . htmlspecialchars($personal_info['email']) . "</span></div>";
                    echo "<div class='form-group1'><label>Street Address:</label><span>" . htmlspecialchars($personal_info['street_add']) . "</span></div>";
                    echo "<div class='form-group1'><label>City:</label><span>" . htmlspecialchars($personal_info['city']) . "</span></div>";
                    echo "<div class='form-group1'><label>State:</label><span>" . htmlspecialchars($personal_info['state']) . "</span></div>";
                    echo "<div class='form-group1'><label>ZIP Code:</label><span>" . htmlspecialchars($personal_info['zip_code']) . "</span></div>";
                    echo "</div>";
                    // Family Details Section
                    echo "<h3>Family Details</h3>";
                    if ($fam_det) {
                        echo "<div class='form-grid1'>";
                        echo "<div class='form-group1'><label>Marital Status:</label><span>" . htmlspecialchars($fam_det['marital_status']) . "</span></div>";
                        echo "<div class='form-group1'><label>Medical Condition:</label><span>" . htmlspecialchars($fam_det['medical_condition']) . "</span></div>";
                        echo "<div class='form-group1'><label>Disabilities:</label><span>" . htmlspecialchars($fam_det['disabilities']) . "</span></div>";
                        echo "</div>";
                    }

                    //Family Members
                    echo "<h3>Family Members</h3>";
                    if (!empty($family_members)) {
                        echo "<div class='form-grid1'>";
                        foreach ($family_members as $member) {
                            echo "<div class='form-group1'><label>Name:</label><span>" . htmlspecialchars($member['fm_name']) . "</span></div>";
                            echo "<div class='form-group1'><label>Relation:</label><span>" . htmlspecialchars($member['fm_relation']) . "</span></div>";
                            echo "<div class='form-group1'><label>Age:</label><span>" . htmlspecialchars($member['fm_age']) . "</span></div>";
                            echo "<div class='form-group1'><label>Occupation:</label><span>" . htmlspecialchars($member['fm_occupation']) . "</span></div>";
                            
                            // Add more fields if needed
                        }
                        echo "</div>";
                    } else {
                        echo "<p>No family members found.</p>";
                    }

                    // Employment Details Section
                    echo "<h3>Employment Details</h3>";
                    if ($emp_det) {
                        echo "<div class='form-grid1'>";
                        echo "<div class='form-group1'><label>Employment Nature:</label><span>" . htmlspecialchars($emp_det['emp_nature']) . "</span></div>";
                        echo "<div class='form-group1'><label>Years of Service:</label><span>" . htmlspecialchars($emp_det['years_of_service']) . "</span></div>";
                        echo "<div class='form-group1'><label>Job Responsibilities:</label><span>" . htmlspecialchars($emp_det['job_responsibilities']) . "</span></div>";
                        echo "</div>";
                    }

                    // Quarter Preference Section
                    echo "<h3>Quarter Preference</h3>";
                    if ($quat_pref) {
                        echo "<div class='form-grid1'>";
                        echo "<div class='form-group1'><label>Quarter Type:</label><span>" . htmlspecialchars($quat_pref['quarter_type']) . "</span></div>";
                        echo "<div class='form-group1'><label>Reason:</label><span>" . htmlspecialchars($quat_pref['reason']) . "</span></div>";
                        echo "<div class='form-group1'><label>Preferred Location:</label><span>" . htmlspecialchars($quat_pref['preferred_location']) . "</span></div>";
                        echo "</div>";
                    }

                    // Faculty Documents Section
                    echo "<h3>Quarter Preference</h3>";
                    if ($faculty_documents) {
                        echo "<div class='form-grid1'>";
                        // Base directory where files are stored
                        $base_dir = '/sqms/faculty/uploads/';  // You should replace this with your actual path

                        // Function to get file extension
                        function getFileExtension($file)
                        {
                            return pathinfo($file, PATHINFO_EXTENSION);
                        }

                        // List of documents from the database
                        $documents = [
                            'Proof of Employment' => $faculty_documents['proof_of_employment'],
                            'Identity Proof' => $faculty_documents['identity_proof'],
                            'Proof of Family' => $faculty_documents['proof_of_family'],
                            'Medical Certificates' => $faculty_documents['medical_certificates'],
                            'Other Documents' => $faculty_documents['other_documents'],
                            'Declaration Form' => $faculty_documents['declaration_form']
                        ];

                        // Loop through the documents and render them
                        foreach ($documents as $label => $file) {
                            if ($file) {
                                // Generate the full file path
                                $file_url = $base_dir . $file;

                                // Determine the file extension
                                $extension = getFileExtension($file);

                                // Check if it's an image or a PDF
                                if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                                    // If it's an image, display an image tag with a clickable link
                                    echo "<div class='form-group1'>
                                            <label>{$label}:</label>
                                            <span><a href='" . htmlspecialchars($file_url) . "' class='document-link' target='_blank'>View Document</a></span>

                                        </div>";
                                } elseif ($extension === 'pdf') {
                                    // If it's a PDF, provide a link to view it in a new tab
                                    echo "<div class='form-group1'>
                                            <label>{$label}:</label>
                                            <span><a href='" . htmlspecialchars($file_url) . "' class='document-link' target='_blank'>View Document</a></span>
                                        </div>";
                                } else {
                                    // For other document types, just display the link
                                    echo "<div class='form-group1'>
                                            <label>{$label}:</label>
                                            <span><a href='" . htmlspecialchars($file_url) . "' class='document-link' target='_blank'>View Document</a></span>
                                        </div>";
                                }
                            }
                        }
                        echo "</div>";
                    }


                    echo "</>";
                } else {
                    echo "<p>No form data found for the given ID.</p>";
                }


                $conn->close();
            } else {
                echo "<p>No form ID provided.</p>";
            }
            ?>

        </section>
    </main>
    <script>
        function submitForm(action, id) {
            document.getElementById('formAction').value = action;
            document.getElementById('formId').value = id;
            document.getElementById('actionForm').submit();
        }
    </script>
</body>


</html>