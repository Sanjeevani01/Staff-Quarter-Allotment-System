<?php
    // Start the session at the very top
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        // Check if the email is stored in the session
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super Admin') {
            header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in
        exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SQMS Admin Dashboard</title>
    <link rel="stylesheet" href="../css/forms.css">
    <style>
        /* .sidebar {
            width: 250px !important;
        } */
        /* Sidebar styling */
        .sidebar h1 {
            font-size: 24px;
            padding: 10px;
        }

        /* Dropdown menu styling */
        .nav-menu h1 {
            cursor: pointer;
            margin: 0;
            padding: 10px;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .submenu {
            display: none;
            list-style: none;
            padding-left: 15px;
        }

        /* Arrow styling */
        .arrow {
            border: solid #fff;
            border-width: 0 2px 2px 0;
            display: inline-block;
            padding: 3px;
            margin-right: 10px;
            transform: rotate(45deg);
            transition: transform 0.3s;
        }

        .arrow.up {
            transform: rotate(-135deg);
        }

        .nav-menu li {
            margin: 0;
            padding: 5px 0;
        }

        /* Active menu item styling */
        .nav-menu li a.active {
            background-color: #f3e5f5;  /* Light violet background */
            color: purple;            /* Deep purple text */
            padding: 8px 15px;         /* Add some padding for better visibility */
            border-radius: 4px;        /* Rounded corners */
            display: block;            /* Make the highlight fill the width */
            text-decoration: none;     /* Remove underline from link */
        }

        /* Hover effect for menu items */
        .nav-menu li a:hover {
            background-color: #e1bee7;  /* Slightly darker violet on hover */
            color: #4a148c;            /* Darker purple text on hover */
            padding: 8px 15px;
            border-radius: 4px;
            transition: all 0.3s ease;  /* Smooth transition for hover effect */
        }

        /* Normal link state */
        .nav-menu li a {
            padding: 8px 15px;
            display: block;
            text-decoration: none;
            transition: all 0.3s ease;
        }
    </style>
</head>
<body>
    <aside class="sidebar">
        <h1>SQMS Super Admin Dashboard</h1>
        <nav>
            <ul class="nav-menu">
                <h1 onclick="toggleMenu('formsMenu')">
                    Forms
                    <span class="arrow"></span>
                </h1>
                <ul id="formsMenu" class="submenu">
                    <li><a href="form.php">View Forms</a></li>
                    <!-- <li><a href="approved_form.php">Approved Forms</a></li>
                    <li><a href="declined_form.php">Declined Forms</a></li>
                    <li><a href="pending_form.php">Pending Forms</a></li> -->
                </ul>
            </ul>
        </nav>
        <nav>
            <ul class="nav-menu">
                <h1 onclick="toggleMenu('quartersMenu')">
                    Quarters
                    <span class="arrow"></span>
                </h1>
                <ul id="quartersMenu" class="submenu">
                    
                    <li><a href="view_quarters.php">View Quarters</a></li>
                    <li><a href="view_resident.php">View Residents</a></li>
                </ul>
            </ul>
        </nav>

        <nav>
            <ul class="nav-menu"  style= text-align:center;>
                <li><a href="../logout.php">Logout</a></li>
                
            </ul>
        </nav>
        
    </aside>

    <script>
        // Get current page URL
        const currentPage = window.location.pathname.split('/').pop();
        
        // Store menu states in localStorage
        function toggleMenu(menuId) {
            const menu = document.getElementById(menuId);
            const arrow = menu.previousElementSibling.querySelector('.arrow');
            const isOpen = menu.style.display === 'block';
            
            // Toggle menu visibility
            menu.style.display = isOpen ? 'none' : 'block';
            
            // Toggle arrow direction
            arrow.classList.toggle('up', !isOpen);
            
            // Save state to localStorage
            localStorage.setItem(menuId + 'State', !isOpen ? 'open' : 'closed');
        }

        // Function to restore menu states
        function restoreMenuStates() {
            const menus = ['formsMenu', 'quartersMenu'];
            
            menus.forEach(menuId => {
                const menu = document.getElementById(menuId);
                const state = localStorage.getItem(menuId + 'State');
                const arrow = menu.previousElementSibling.querySelector('.arrow');
                
                if (state === 'open' || shouldOpenMenu(menuId)) {
                    menu.style.display = 'block';
                    arrow.classList.add('up');
                }
            });

            // Highlight active link
            const links = document.querySelectorAll('.nav-menu a');
            links.forEach(link => {
                if (link.getAttribute('href') === currentPage) {
                    link.classList.add('active');
                }
            });
        }

        // Function to check if menu should be open based on current page
        function shouldOpenMenu(menuId) {
            const menu = document.getElementById(menuId);
            const links = menu.getElementsByTagName('a');
            
            for (let link of links) {
                if (link.getAttribute('href') === currentPage) {
                    return true;
                }
            }
            return false;
        }

        // Initialize menu states when page loads
        document.addEventListener('DOMContentLoaded', restoreMenuStates);
    </script>
</body>
</html>