<?php



    // Start the session at the very top
        session_start();
        // Check if the email is stored in the session
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super Admin') {
            header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in
        exit();
}



// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from campus_quarters table joined with residents table
$sql = "SELECT cq.campus_quarter_id, cq.campus_name, cq.block_name, cq.type, cq.building, cq.total_quarters, cq.allotted_quarters, cq.vacancies, cq.remarks,
            r.resident_id, r.name, r.flat_no, r.designation, r.institute 
        FROM campus_quarters cq
        INNER JOIN residents r ON cq.campus_quarter_id = r.campus_quarter_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/forms.css">

    <title>Super Admin Dashboard - SQMS</title>
    <style>
        /* Main theme colors and settings */
        :root {
            --primary-color: indigo;
            --secondary-color: indigo;
            --background-color: #f0f0f0;
            --white: #ffffff;
            --gray: #333333;
            --light-gray: #e0e0e0;
            --table-row-hover: #ddd;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: var(--background-color);
            color: var(--gray);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 1rem;
        }

        .sidebar h1 {
            font-size: 1.5rem;
            margin-bottom: 2rem;
            text-align: center;
        }

        .main-content {
            flex-grow: 1;
            padding: 2rem;
            overflow-y: auto;
        }

        .dashboard-section {
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .header-search-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .search-bar {
            padding: 0.5rem;
            border: 1px solid var(--light-gray);
            border-radius: 4px;
            font-size: 1rem;
        }

        .search-button {
            padding: 0.5rem 1rem;
            margin-left: 10px;
            background-color: var(--primary-color);
            color: var(--white);
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s ease;
        }

        .search-button:hover {
            background-color: var(--secondary-color);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
            font-size: 1rem;
        }

        th,
        td {
            padding: 0.75rem;
            text-align: left;
            border: 1px solid var(--light-gray);
        }

        th {
            background-color: var(--primary-color);
            color: #ffffff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: var(--table-row-hover);
        }
    </style>
</head>
<body>
    <?php include_once('../super_admin/sidebar.php');?>

    <main class="main-content">
        <section class="dashboard-section">
            <!-- Header with title and search bar + button -->
            <div class="header-search-container">
                <h2>Campus Quarters with Residents</h2>
                <div>
                    <input type="text" id="search-bar" class="search-bar" placeholder="Search by Resident Name">
                    <button class="search-button" onclick="filterTable()">Search</button>
                </div>
            </div>

            <?php
            if ($result && $result->num_rows > 0) {
                echo "<table id='data-table'>";
                echo "<tr>
                        <th>Resident Name</th>
                        <th>Flat Number</th>
                        <th>Institute</th>
                        <th>Designation</th>
                        <th>Campus Name</th>
                        <th>Block Name</th>
                        <th>Type</th>
                    </tr>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";                 echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['flat_no']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['institute']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['designation']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['campus_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['block_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['type']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No data found in campus_quarters or residents tables.</p>";
            }

            // Close the database connection
            $conn->close();
            ?>
        </section>
    </main>

    <script>
        function filterTable() {
            // Get search bar input and table rows
            const input = document.getElementById('search-bar').value.toLowerCase();
            const table = document.getElementById('data-table');
            const rows = table.getElementsByTagName('tr');

            // Loop through rows and filter based on the 'name' column
            for (let i = 1; i < rows.length; i++) {
                const nameCell = rows[i].getElementsByTagName('td')[0]; // Resident Name is in the first column
                if (nameCell) {
                    const name = nameCell.textContent || nameCell.innerText;
                    rows[i].style.display = name.toLowerCase().indexOf(input) > -1 ? '' : 'none';
                }
            }
        }
    </script>
</body>
</html>
