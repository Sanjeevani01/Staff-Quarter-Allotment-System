6a0dad<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="../css/forms.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard - SQMS</title>

    <style>
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: purple;
            padding: 1rem;
            color: #fff;
            height: 100vh;
            position: fixed;
        }

        .sidebar h1 {
            font-size: 1.5rem;
            margin-bottom: 2rem;
            text-align: center;
        }

        .nav-menu {
            list-style-type: none;
            padding: 0;
        }

        .nav-menu li {
            margin-bottom: 1rem;
        }

        .nav-menu a {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .nav-menu a:hover {
            background-color: white;
            color: #333; /* Change text color when hovered */
        }

        .nav-menu a.active {
            background-color: white;
            color: #333; /* Change text color when active */
        }
    </style>
</head>

<body>
    <aside class="sidebar">
        <h1>SQMS Super Admin Dashboard</h1>
        <nav>
            <ul class="nav-menu">
                <li><a href="dash_super.php" class="active">View Form</a></li>
                <li><a href="view_quarters.php">View Quarters</a></li>
                <li><a href="view_residence.php">View Residence</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <section id="view-forms" class="dashboard-section">
            <h2>View Forms</h2>
            <table>
                <thead>
                    <tr>
                        <th>EMP_ID</th>
                        <th>Name</th>
                        <th>Email ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Replace with your database connection and query
                    $conn = new mysqli("localhost", "root", "", "sqms");
                    $sql = "SELECT emp_id, name, email, fac_id_fk FROM personal_info";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . $row["emp_id"] . "</td>
                                    <td>" . $row["name"] . "</td>
                                    <td>" . $row["email"] . "</td>
                                    <td><a href='view_form.php?id=" . $row["fac_id_fk"] . "' class='btn'>View Form</a></td>
                                </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No forms available</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </section>
    </main>
</body>

</html>
