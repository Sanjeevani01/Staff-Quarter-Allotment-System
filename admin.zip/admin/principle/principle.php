<?php
// Database connection
$servername = "localhost";
$username = "root"; // Database username
$password = ""; // Database password
$dbname = "sqms"; // Your database name
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle approve/decline actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'] === 'approve' ? 'approved' : 'declined';

    // Update the status of the user in the personal_info table
    $sql = "UPDATE personal_info SET status='$action' WHERE emp_id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "User status updated successfully.";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch all pending users and their related data
$sql = "
    SELECT 
        pi.emp_id, pi.name, pi.email,
        fd.marital_status, fd.fm_name,fd.fm_relation,fd.fm_age,fd.fm_occupation,fd.medical_condition,fd.disabilities,
        ed.emp_nature, ed.years_of_service,ed.job_responsibilities,
        qp.quarter_type, qp.reason, qp.preferred_location,
        doc.proof_of_employment, doc.identity_proof, doc.proof_of_family, doc.medical_certificates, doc.other_documents, doc.declaration_form
    FROM 
        personal_info pi
    LEFT JOIN 
        fam_det fd ON pi.fac_id_fk = fd.fac_id_fk
    LEFT JOIN 
        emp_det ed ON pi.fac_id_fk = ed.fac_id_fk
    LEFT JOIN 
        quat_perf qp ON pi.fac_id_fk = qp.fac_id_fk
    LEFT JOIN 
        faculty_documents doc ON pi.fac_id_fk = doc.fac_id_fk
    WHERE 
        pi.principle_status = 'Approved'
";
$result = $conn->query($sql);
?>

<!DOCTYPE html> 
<html>

<head>
    <title>SIOM | Principle-Dashboard</title>
</head>

<body>
    <h1>User Approval Panel</h1>

    <?php if ($result->num_rows > 0): ?>
        <table border="1" cellpadding="10">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Marital Status</th>
                    <th>Medical Condition</th>
                    <th>Disabilities </th>
                    <th>Employment Nature</th>
                    <th>Service Years</th>
                    <th>Job Responsibilities </th>
                    <th>quarter_type</th>
                    <th>Reason</th>
                    <th>Preferred Location</th>
                    <th>Proof of Employment</th>
                    <th>Identity Proof</th>
                    <th>Proof of Family Members</th>
                    <th>Medical Certificates</th>
                    <th>Other Documents</th>
                    <th>Declaration Form</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['emp_id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['principle_status']; ?></td>
                        <td><?php echo $row['marital_status']; ?></td>
                        <td><?php echo $row['medical_condition']; ?></td>
                        <td><?php echo $row['disabilities']; ?></td>
                        <td><?php echo $row['emp_nature']; ?></td>
                        <td><?php echo $row['years_of_service']; ?></td>
                        <td><?php echo $row['job_responsibilities']; ?></td>
                        <td><?php echo $row['quarter_type']; ?></td>
                        <td><?php echo $row['reason']; ?></td>
                        <td><?php echo $row['preferred_location']; ?></td>
                        <td>
                            <?php
                            $proof_of_employment_path = '/sqms/faculty/uploads/' . $row['proof_of_employment'];
                            // Display image if exists
                            if (!empty($row['proof_of_employment']) && file_exists($_SERVER['DOCUMENT_ROOT'] . '/' . $proof_of_employment_path)): ?>
                                <img src="<?php echo $proof_of_employment_path; ?>" alt="Proof of Employment" style="width: 100px; height: auto;">
                            <?php else: ?>
                                <span style="color:red;">No Image <br> File not Uploaded</span>
                                <br>
                            
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $identity_proof_path = '/sqms/faculty/uploads/' . $row['identity_proof'];
                            // Display image if the file exists
                            if (!empty($row['identity_proof']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $identity_proof_path)): ?>
                                <img src="<?php echo $identity_proof_path; ?>" alt="Identity Proof" style="width: 100px; height: auto;">
                            <?php else: ?>
                                <span style="color:red;">No Image</span>
                                <br>
                                
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php
                            $proof_of_family_path = '/sqms/faculty/uploads/' . $row['proof_of_family'];
                            // Display image if the file exists
                            if (!empty($row['proof_of_family']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $proof_of_family_path)): ?>
                                <img src="<?php echo htmlspecialchars($proof_of_family_path); ?>" alt="Proof of Family" style="width: 100px; height: auto;">
                            <?php else: ?>
                                <span style="color:red;">No Image</span>
                                <br>
                                
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php
                            $medical_certificates_path = '/sqms/faculty/uploads/' . $row['medical_certificates'];
                            // Display image if the file exists
                            if (!empty($row['medical_certificates']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $medical_certificates_path)): ?>
                                <img src="<?php echo htmlspecialchars($medical_certificates_path); ?>" alt="Medical Certificates" style="width: 100px; height: auto;">
                            <?php else: ?>
                                <span style="color:red;">No Image or File not Uploaded</span>
                                <br>
                                
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php
                            $other_documents_path = '/sqms/faculty/uploads/' . $row['other_documents'];
                            // Display image if the file exists
                            if (!empty($row['other_documents']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $other_documents_path)): ?>
                                <img src="<?php echo htmlspecialchars($other_documents_path); ?>" alt="Other Documents" style="width: 100px; height: auto;">
                            <?php else: ?>
                                <span style="color:red;">No Image</span>
                                <br>
                                
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php
                            $declaration_form_path = '/sqms/faculty/uploads/' . $row['declaration_form'];
                            // Display image if the file exists
                            if (!empty($row['declaration_form']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $declaration_form_path)): ?>
                                <img src="<?php echo htmlspecialchars($declaration_form_path); ?>" alt="Declaration Form" style="width: 100px; height: auto;">
                            <?php else: ?>
                                <span style="color:red;">No Image</span>
                                <br>
                                
                            <?php endif; ?>
                        </td>

                        <td>
                            <a href="principle.php?action=approve&id=<?php echo $row['emp_id']; ?>" class='btn btn-success'>Approve</a>
                            <a href="principle.php?action=decline&id=<?php echo $row['emp_id']; ?>" class='btn btn-danger'>Decline</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>



        </table>
    <?php else: ?>
        <p>No users pending approval.</p>
    <?php endif; ?>

    <?php $conn->close(); ?>
</body>

</html>
