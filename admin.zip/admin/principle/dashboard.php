<?php
session_start(); // Start the session at the very top

// Check if the email is stored in the session
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Principle') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
   exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="../css/forms.css">
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Principle Dashboard - SQMS</title>


</head>

<body>

<?php include_once('../principle/sidebar.php');?>

    <main class="main-content">
        <section id="view-forms" class="dashboard-section">
            <h2>View Forms</h2>
            <table>
                <thead>
                    <tr>
                        <th>EMP_ID</th>
                        <th>Name</th>
                        <th>Email ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Replace with your database connection and query
                    $conn = new mysqli("localhost", "root", "", "sqms",3308);
                    $sql = "SELECT emp_id, name, email, fac_id_fk FROM personal_info";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . $row["emp_id"] . "</td>
                                    <td>" . $row["name"] . "</td>
                                    <td>" . $row["email"] . "</td>
                                    <td><a href='view_full_form.php?id=" . $row["fac_id_fk"] . "' class='btn'>View Form</a></td>
                                </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No forms available</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </section>
    </main>
</body>

</html>