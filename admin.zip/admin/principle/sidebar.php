<?php
    // Start the session at the very top
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        // Check if the email is stored in the session
        if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Principle') {
            header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in
        exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="../css/forms.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Principal Dashboard - SQMS</title>
    <style>
        /* Sidebar Styles */
        .sidebar {
            background-color: purple; /* Example sidebar color */
            padding: 20px;
            width: 250px;
            height: auto;
        }

        .sidebar h1 {
            color: white;
            font-size: 1.5em;
            margin-bottom: 20px;
        }

        .nav-menu {
            list-style-type: none;
            padding: 0;
        }

        .nav-menu li {
            margin-bottom: 10px;
        }

        .nav-menu li a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: block;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        /* Hover effect */
        .nav-menu li a:hover {
            background-color: white;
            color: #4b2e83;
        }

        /* Active page styling */
        .nav-menu li a.active {
            background-color: white;
            color: #4b2e83;
        }
    </style>
</head>

<body>
    <aside class="sidebar">
        <h1>SQAS Principal Dashboard</h1>
        <nav>
            <ul class="nav-menu">
                <li><a href="dashboard.php">View Forms</a></li>
                <li><a href="approved_form.php">Approved Forms</a></li>
                <li><a href="declined_form.php">Declined Forms</a></li>
                <li><a href="pending_form.php">Pending Forms</a></li>
                
            </ul>
            <ul class="nav-menu" style= text-align:center;>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </nav>
    </aside>
    <script>
        // Get the current URL path
        const currentPath = window.location.pathname.split('/').pop();

        // Add 'active' class to the corresponding menu item
        const menuItems = document.querySelectorAll('.nav-menu li a');
        
        menuItems.forEach(item => {
            const itemPath = item.getAttribute('href').split('/').pop();
            if (itemPath === currentPath) {
                item.classList.add('active');
            }
        });
    </script>
</body>
</html>
