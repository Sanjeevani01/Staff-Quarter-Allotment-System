<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Principle') {
    header("Location: /sqms/admin/login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['id'])) {
        $fac_id_fk = $_POST['id'];
        $action = $_POST['action'] === 'approve' ? 'Approved' : 'Declined';

        // Use prepared statement for security
        $stmt = $conn->prepare("UPDATE personal_info SET principle_status = ? WHERE fac_id_fk = ?");
        $stmt->bind_param("ss", $action, $fac_id_fk);

        if ($stmt->execute()) {
            header("Location: pending_form.php");
            exit();
        } else {
            echo "Error updating record: " . $stmt->error;
        }
    } else {
        echo "Invalid request.";
    }
} else {
    echo "Invalid request method.";
}

$conn->close();
?>
