<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_quarter'])) {
    $quarter_id = $_POST['quarter_id'];
    $campus_name = $_POST['campus_name'];
    $block_name = $_POST['block_name'];
    $type = $_POST['type'];
    $total_quarters = $_POST['total_quarters'];
    $allotted_quarters = $_POST['allotted_quarters'];
    $vacancies = $_POST['vacancies'];

    $update_query = "UPDATE campus_quarters 
                     SET campus_name = ?, block_name = ?, type = ?, total_quarters = ?, allotted_quarters = ?, vacancies = ? 
                     WHERE campus_quarter_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssiiii", $campus_name, $block_name, $type, $total_quarters, $allotted_quarters, $vacancies, $quarter_id);

    if ($stmt->execute()) {
        echo "<script>alert('Quarter updated successfully!'); window.location.href='campus_quarter.php';</script>";
    } else {
        echo "<script>alert('Error updating quarter: " . $conn->error . "'); window.location.href='campus_quarter.php';</script>";
    }

    $stmt->close();
}

$conn->close();
?>
