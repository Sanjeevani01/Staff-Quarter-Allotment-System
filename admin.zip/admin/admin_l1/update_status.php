<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    echo "Unauthorized";
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port );

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id']) && isset($_POST['status'])) {
        $id = intval($_POST['id']);
        $status = $_POST['status'];

        if ($status !== 'Completed' && $status !== 'Rejected') {
            echo "Invalid status";
            exit();
        }

        $stmt = $conn->prepare("UPDATE maintenance SET status=? WHERE maintenance_id=?");
        $stmt->bind_param("si", $status, $id);

        if ($stmt->execute()) {
            echo "success";
            echo '<script>
            setTimeout(function() {
                window.location.href = "status.php";
            }, 3000); // Redirect after 3 seconds
            </script>';
        } else {
            echo "error";
        }

        $stmt->close();
    }
}

$conn->close();
?>