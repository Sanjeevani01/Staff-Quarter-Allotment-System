<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<?php
// Database connection
$servername = "localhost";
$username = "root"; // Database username
$password = ""; // Database password
$dbname = "sqms"; // Your database name
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle approve/decline actions
// if (isset($_GET['action']) && isset($_GET['id'])) {
//     $id = intval($_GET['id']);
//     $action = $_GET['action'] === 'approve' ? 'Approved' : 'Declined';

//     // Update the status of the user in the `personal_info` table
//     $sql = "UPDATE personal_info SET status='$action' WHERE emp_id=$id";
//     if ($conn->query($sql) === TRUE) {
//         // Successful update
//         echo "User status updated successfully.";
//         // Redirect to pending_form.php after successful update
//         header("Location: pending_form.php"); // Correct syntax
//         exit(); // Ensure no further code runs after the header redirect
//     } else {
//         // Error updating the record
//         echo "Error updating record: " . $conn->error;
//         // Redirect back to view_form.php in case of an error
//         header("Location: view_form.php"); // Correct syntax
//         exit(); // Ensure no further code runs after the header redirect
//     }
// }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <link rel="stylesheet" href="../css/forms.css">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SQMS</title>
    <style>
        :root {
            --primary-color: #4a0e78;
            --secondary-color: #6a1b9a;
            --background-color: #f0f0f0;
            --white: #ffffff;
            --gray: #333333;
            --light-gray: #e0e0e0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: var(--background-color);
            color: var(--gray);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }


        .main-content {
            flex-grow: 1;
            padding: 2rem;
            overflow-y: auto;
        }

        .dashboard-section {
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        h3 {
            color: var(--secondary-color);
            margin-top: 2rem;
            margin-bottom: 1rem;
        }

        .form-grid1 {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .form-group1 {
            background-color: var(--light-gray);
            padding: 1rem;
            border-radius: 4px;
        }

        .form-group1 label {
            font-weight: bold;
            margin-bottom: 0.5rem;
            display: block;
        }

        .form-group1 span {
            display: block;
            margin-top: 0.5rem;
            background-color: var(--white);
            padding: 0.5rem;
            border-radius: 4px;
        }

        .btn {
            display: inline-block;
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: var(--white);
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            cursor: pointer;
            border: none;
        }

        .btn:hover {
            background-color: var(--secondary-color);
        }

        .btn-container {
            margin-top: 2rem;
            display: flex;
            justify-content: center;
            /* Change this from flex-end to center */
            gap: 10px;
        }
    </style>
</head>

<body>
    
<?php include_once('../admin_l1/sidebar.php'); ?>


    <main class="main-content">
        <section class="dashboard-section">
            <h2>View Form Details</h2>
            <?php
            // Check if an ID is provided
            if (isset($_GET['id'])) {
                $fac_id_fk = $_GET['id'];

                // Replace with your database connection details
                $conn = new mysqli("localhost", "root", "", "sqms", 3308);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch data from personal_info table
                $sql_personal = "SELECT * FROM personal_info WHERE fac_id_fk = ?";
                $stmt_personal = $conn->prepare($sql_personal);
                $stmt_personal->bind_param("s", $fac_id_fk);
                $stmt_personal->execute();
                $result_personal = $stmt_personal->get_result();
                $personal_info = $result_personal->fetch_assoc();

                // Fetch data from emp_det table
                $sql_emp = "SELECT * FROM emp_det WHERE fac_id_fk = ?";
                $stmt_emp = $conn->prepare($sql_emp);
                $stmt_emp->bind_param("s", $fac_id_fk);
                $stmt_emp->execute();
                $result_emp = $stmt_emp->get_result();
                $emp_det = $result_emp->fetch_assoc();

                // Fetch data from quat_perf table
                $sql_quat = "SELECT * FROM quat_perf WHERE fac_id_fk = ?";
                $stmt_quat = $conn->prepare($sql_quat);
                $stmt_quat->bind_param("s", $fac_id_fk);
                $stmt_quat->execute();
                $result_quat = $stmt_quat->get_result();
                $quat_pref = $result_quat->fetch_assoc();

                if ($quat_pref) {
                    echo "<h3>Quarter Preference</h3>";

                    echo "<div class='form-grid1'>";

                    // Personal Information Section

                    echo "<div class='form-group1'><label>Name:</label><span>" . htmlspecialchars($personal_info['name']) . "</span></div>";
                    echo "<div class='form-group1'><label>Designation:</label><span>" . htmlspecialchars($personal_info['designation']) . "</span></div>";
                    echo "<div class='form-group1'><label>Department:</label><span>" . htmlspecialchars($personal_info['department']) . "</span></div>";
                    echo "<div class='form-group1'><label>Institute:</label><span>" . htmlspecialchars($personal_info['institute']) . "</span></div>";
                    echo "<div class='form-group1'><label>Date of Joining:</label><span>" . htmlspecialchars($personal_info['date_of_joining']) . "</span></div>";
                    echo "<div class='form-group1'><label>Phone No:</label><span>" . htmlspecialchars($personal_info['phone_no']) . "</span></div>";
                    echo "<div class='form-group1'><label>Email:</label><span>" . htmlspecialchars($personal_info['email']) . "</span></div>";
                    // echo "<div class='form-group1'><label>Street Address:</label><span>" . htmlspecialchars($personal_info['street_add']) . "</span></div>";
                    // echo "<div class='form-group1'><label>City:</label><span>" . htmlspecialchars($personal_info['city']) . "</span></div>";
                    // echo "<div class='form-group1'><label>State:</label><span>" . htmlspecialchars($personal_info['state']) . "</span></div>";
                    // echo "<div class='form-group1'><label>ZIP Code:</label><span>" . htmlspecialchars($personal_info['zip_code']) . "</span></div>";
                    echo "</div>";

                    // Employment Details Section
                    echo "<h3>Employment Details</h3>";
                    if ($emp_det) {
                        echo "<div class='form-grid1'>";
                        echo "<div class='form-group1'><label>Employment Nature:</label><span>" . htmlspecialchars($emp_det['emp_nature']) . "</span></div>";
                        echo "<div class='form-group1'><label>Years of Service:</label><span>" . htmlspecialchars($emp_det['years_of_service']) . "</span></div>";
                        echo "<div class='form-group1'><label>Job Responsibilities:</label><span>" . htmlspecialchars($emp_det['job_responsibilities']) . "</span></div>";
                        echo "</div>";
                    }

                    // Quarter Preference Section
                    echo "<h3>Quarter Preference</h3>";
                    if ($quat_pref) {
                        echo "<div class='form-grid1'>";
                        echo "<div class='form-group1'><label>Quarter Type:</label><span>" . htmlspecialchars($quat_pref['quarter_type']) . "</span></div>";
                        echo "<div class='form-group1'><label>Reason:</label><span>" . htmlspecialchars($quat_pref['reason']) . "</span></div>";
                        echo "<div class='form-group1'><label>Preferred Location:</label><span>" . htmlspecialchars($quat_pref['preferred_location']) . "</span></div>";
                        echo "</div>";
                    }


                    echo "</>";
                } else {
                    echo "<p>No form data found for the given ID.</p>";
                }


                $conn->close();
            } else {
                echo "<p>No form ID provided.</p>";
            }
            ?>

            <?php if ($personal_info['admin_status'] === 'Pending') : ?>
                <div class="btn-container">
                    <!-- Approve Button -->
                    <a href="add_resident.php?id=<?php echo urldecode($personal_info['fac_id_fk']); ?>&name=<?php echo urlencode($personal_info['name']); ?>&designation=<?php echo urlencode($personal_info['designation']); ?>&department=<?php echo urlencode($personal_info['department']); ?>&institute=<?php echo urlencode($personal_info['institute']); ?>&email=<?php echo urlencode($personal_info['email']); ?>"
                        class="btn btn-success">Approve by Admin</a>


                    <!-- Decline Button -->
                    <a href="approve_decline.php?id=<?php echo urldecode($fac_id_fk); ?>&action=decline"
                        class="btn btn-danger">Decline by Admin</a>

                    <!-- Hidden Form -->
                    <form id="actionForm" action="add_resident.php" method="POST" style="display: none;">
                        <input type="hidden" name="action" id="formAction">
                        <input type="hidden" name="id" id="formId">
                    </form>

                </div>
            <?php endif; ?>



        </section>
    </main>
    <script>
        function submitForm(action, id) {
            document.getElementById('formAction').value = action;
            document.getElementById('formId').value = id;
            document.getElementById('formName').value = name;
            document.getElementById('formEmail').value = email;
            document.getElementById('formDesignation').value = designation;
            document.getElementById('formDepartment').value = department;
            document.getElementById('formInstitute').value = institute;
            document.getElementById('actionForm').submit();
        }
    </script>
</body>


</html>