<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Handle deletion
if (isset($_POST['delete_quarter'])) {
    $quarter_id = $_POST['quarter_id'];

    $delete_query = "DELETE FROM campus_quarters WHERE campus_quarter_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $quarter_id);

    if ($stmt->execute()) {
        $message = "Quarter deleted successfully!";
    } else {
        $message = "Error deleting quarter: " . $conn->error;
    }
    $stmt->close();
}

// Search functionality for campus name
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$quarters_query = "SELECT campus_quarter_id, campus_name, block_name, type, total_quarters, allotted_quarters, vacancies 
                   FROM campus_quarters";
if (!empty($search)) {
    $quarters_query .= " WHERE campus_name LIKE '%$search%'";
}
$quarters_query .= " ORDER BY campus_quarter_id ASC";
$quarters_result = $conn->query($quarters_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus Quarters - SQMS</title>
    <link rel="stylesheet" href="../css/forms.css">
    <style>
        /* Your original styling */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #4B0082;
            margin-bottom: 20px;
        }

        .search-container {
            display: flex;
            align-items: center;
        }

        .search-container input {
            padding: 0.5rem;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            padding: 0.5rem 1rem;
            background-color: purple;
            color: white;
            font-size: 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 0.5rem;
        }

        .search-container button:hover {
            background-color: #5A2A7B;
        }

        .delete-btn {
            background-color: #dc3545;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .update-btn {
            background-color: #007bff;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .update-btn:hover {
            background-color: #007bff;
        }

        .add-quarter-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .add-quarter-btn {
            background-color: purple;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        .add-quarter-btn a {
            text-decoration: none;
            color: white;
        }

        .add-quarter-btn:hover {
            background-color: #5A2A7B;
        }
    </style>
</head>

<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>

    <main class="main-content">
        <section class="dashboard-section">
            <!-- Title and search bar aligned opposite to each other -->
            <div class="section-header">
                <h1>Campus Quarters</h1>
                <div class="search-container">
                    <form action="" method="GET">
                        <input type="text" placeholder="Search by campus name" name="search"
                            value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit">Search</button>
                    </form>
                </div>
            </div>



            <!-- Display message if any -->
            <?php if (!empty($message)): ?>
                <div id="message" class="message">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Table with data -->
            <?php if ($quarters_result && $quarters_result->num_rows > 0): ?>
                <table class="quarters-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Campus Name</th>
                            <th>Block Name</th>
                            <th>Type</th>
                            <th>Total Quarters</th>
                            <th>Allotted</th>
                            <th>Vacancies</th>
                            <th>Action</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $quarters_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['campus_quarter_id']); ?></td>
                                <td><?php echo htmlspecialchars($row['campus_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['block_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['type']); ?></td>
                                <td><?php echo htmlspecialchars($row['total_quarters']); ?></td>
                                <td><?php echo htmlspecialchars($row['allotted_quarters']); ?></td>
                                <td><?php echo htmlspecialchars($row['vacancies']); ?></td>
                                <td>
                                    <form method="POST" action="update_quarter.php">
                                        <input type="hidden" name="quarter_id" value="<?php echo $row['campus_quarter_id']; ?>">
                                        <button type="submit" name="update_quarter" class="update-btn">Update</button>
                                    </form>
                                </td>
                                <td>
                                    <form method="POST" onsubmit="return confirmDelete();">
                                        <input type="hidden" name="quarter_id" value="<?php echo $row['campus_quarter_id']; ?>">
                                        <button type="submit" name="delete_quarter" class="delete-btn">Delete</button>
                                    </form>
                                </td>

                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-message">
                    No campus quarters found in the database.
                </div>
            <?php endif; ?>

        </section>
        <div class="add-quarter-container">
            <button class="add-quarter-btn"><a href="add_quarter.php">Add Quarter</a></button>
        </div>
    </main>


</body>

</html>

<?php
$conn->close();
?>