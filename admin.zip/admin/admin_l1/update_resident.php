<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$resident_id = isset($_GET['resident_id']) ? intval($_GET['resident_id']) : 0;
$resident = null;

if ($resident_id) {
    $query = "SELECT flat_no, name, designation, department, institute FROM residents WHERE resident_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $resident_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $resident = $result->fetch_assoc();
    $stmt->close();
}

if (!$resident) {
    echo "<div class='error-message'>Resident not found.</div>";
    exit();
}

if (isset($_POST['save_changes'])) {
    $name = trim($_POST['name']);
    $designation = trim($_POST['designation']);
    $designation = trim($_POST['department']);
    $institute = trim($_POST['institute']);
    $resident_details = trim($_POST['resident_details']);

    $update_query = "UPDATE residents SET name = ?, designation = ?, department=?, institute = ? WHERE resident_id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ssssi", $name, $designation, $department, $institute, $resident_id);

    $update_query = "Select * from residents where department = "MCA";
    $stmt = $conn->prepare($update_query);

    if ($stmt->execute()) {
        header("Location: residents.php?message=Resident+updated+successfully");
        exit();
    } else {
        $error = "Error updating resident details.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <title>Update Resident - SQMS</title>
    <link rel="stylesheet" href="../css/forms.css">

    <style>

        /* Container for the form */
        .form-container {
            max-width: 1500px;
            margin: 10px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        /* Form field style */
        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group select,
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group button {
            width: 100%;
            padding: 12px;
            background-color: purple;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-group button:hover {
            background-color: #45a049;
        }

        /* Message styling */
        .message {
            margin-top: 20px;
            padding: 12px;
            border-radius: 5px;
            font-weight: bold;
        }

        .message.success {
            background-color: #4CAF50;
            color: white;
        }

        .message.error {
            background-color: #f44336;
            color: white;
        }
        input:invalid {
            border-color: red;
        }
        .error-text {
            margin-top: 5px;
        }

    </style>
</head>
<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>
    
    <main class="main-content">
        <section class="form-container">
            <h2 class="form-title">Edit Resident Details</h2>

            <?php if (isset($error)): ?>
                <div class="error-message"> <?php echo $error; ?> </div>
            <?php endif; ?>

            <form method="POST" class="styled-form">
                <div class="form-group">
                    <label for="flat_no">Flat No:</label>
                    <input type="text" id="flat_no" name="flat_no" value="<?php echo htmlspecialchars($resident['flat_no']); ?>" readonly>
                </div>

                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($resident['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="designation">Designation:</label>
                    <input type="text" id="designation" name="designation" value="<?php echo htmlspecialchars($resident['designation']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="department">Department:</label>
                    <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($resident['department']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="institute">Institution:</label>
                    <input type="text" id="institute" name="institute" value="<?php echo htmlspecialchars($resident['institute']); ?>" required>
                </div>
                <h2 class="form-title">Resident Details</h2>
                <p><strong>Total MCA Residents:</strong> <?php echo $mca_count; ?></p>


 

                <div class="form-group">
                    <button type="submit" name="save_changes" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </section>
    </main>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const nameInput = document.getElementById('name');
            const designationInput = document.getElementById('designation');
            const departmentInput = document.getElementById('department');
            const instituteInput = document.getElementById('institute');

            // Utility function to show error message
            function showError(input, message) {
                let error = input.parentElement.querySelector('.error-text');
                if (!error) {
                    error = document.createElement('div');
                    error.className = 'error-text';
                    error.style.color = 'red';
                    error.style.fontSize = '0.9em';
                    input.parentElement.appendChild(error);
                }
                error.textContent = message;
            }

            // Utility function to clear error message
            function clearError(input) {
                const error = input.parentElement.querySelector('.error-text');
                if (error) error.remove();
            }

            // Validation functions
            function validateName() {
                const value = nameInput.value.trim();
                if (value.length < 2 || !/^[a-zA-Z\s]+$/.test(value)) {
                    showError(nameInput, "Enter a valid name (only letters, at least 2 characters).");
                    return false;
                } else {
                    clearError(nameInput);
                    return true;
                }
            }

            function validateDesignation() {
                const value = designationInput.value.trim();
                if (value.length < 2) {
                    showError(designationInput, "Designation must be at least 2 characters.");
                    return false;
                } else {
                    clearError(designationInput);
                    return true;
                }
            }
            function validateDepartment() {
                const value = departmentInput.value.trim();
                if (value.length < 2) {
                    showError(departmentInput, "Department must be at least 2 characters.");
                    return false;
                } else {
                    clearError(departmentInput);
                    return true;
                }
            }

            function validateInstitute() {
                const value = instituteInput.value.trim();
                if (value.length < 2) {
                    showError(instituteInput, "Institute name must be at least 2 characters.");
                    return false;
                } else {
                    clearError(instituteInput);
                    return true;
                }
            }

            // Attach events
            nameInput.addEventListener('input', validateName);
            designationInput.addEventListener('input', validateDesignation);
            departmentInput.addEventListener('input', validateDepartment);
            instituteInput.addEventListener('input', validateInstitute);

            // On form submit
            document.querySelector('.styled-form').addEventListener('submit', function (e) {
                const isNameValid = validateName();
                const isDesignationValid = validateDesignation();
                const isDepartmentValid = validateDepartment();
                const isInstituteValid = validateInstitute();

                if (!isNameValid || !isDesignationValid || !isDepartmentValid || !isInstituteValid) {
                    e.preventDefault(); // Stop submission
                }
            });
        });
        </script>

</body>
</html>
