<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="../css/forms.css">
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SQMS</title>

    <style>
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .search-container {
            display: flex;
        }

        .search-container input {
            padding: 0.5rem;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            padding: 0.5rem 1rem;
            background-color: purple;
            color: white;
            font-size: 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 0.5rem;
        }

        .search-container button:hover {
            background-color: #5A2A7B;
        }
    </style>
</head>

<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>

    <main class="main-content">
        <section id="declined-forms" class="dashboard-section">
            <!-- Container for title and search bar -->
            <div class="section-header">
                <h2>Declined Forms</h2>
                <div class="search-container">
                    <form action="" method="GET">
                        <input type="text" placeholder="Search by name" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit">Search</button>
                    </form>
                </div>
            </div>
            <!-- Table content -->
            <table>
                <thead>
                    <tr>
                        <th>EMP_ID</th>
                        <th>Name</th>
                        <th>Email ID</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Database connection
                    $conn = new mysqli("localhost", "root", "", "sqms", 3308);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Search functionality
                    $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
                    $sql = "SELECT emp_id, name, email, fac_id_fk FROM personal_info WHERE principle_status='Approved' AND admin_status = 'Declined'";
                    if (!empty($search)) {
                        $sql .= " AND name LIKE '%$search%'";
                    }

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . $row["emp_id"] . "</td>
                                    <td>" . $row["name"] . "</td>
                                    <td>" . $row["email"] . "</td>
                                    <td><a href='view_full_form.php?id=" . $row["fac_id_fk"] . "' class='btn'>View Form</a></td>
                                </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No declined forms found</td></tr>";
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
        </section>
    </main>
</body>

</html>
