<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>


<?php
// Database connection setup
$servername = "localhost";
$username = "root"; // Update as per your DB setup
$password = ""; // Update as per your DB setup
$dbname = "sqms"; // Database name

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$campus_name = $block_name = $quarter_type = $resident_name = $flat_no = $designation = $institution = $department = "";
$message = "";

// Fetching values from the URL using GET parameters
$fac_id_fk = isset($_GET['id']) ? $_GET['id'] : '';
$resident_name = isset($_GET['name']) ? $_GET['name'] : '';
$designation = isset($_GET['designation']) ? $_GET['designation'] : '';
$institution = isset($_GET['institution']) ? $_GET['institution'] : '';
$department = isset($_GET['department']) ? $_GET['department'] : '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fac_id_fk = $conn->real_escape_string($_POST['fac_id_fk'] ?? '');
    $campus_name = $conn->real_escape_string($_POST['campus_name'] ?? '');
    $block_name = $conn->real_escape_string($_POST['block_name'] ?? '');
    $quarter_type = $conn->real_escape_string($_POST['quarter_type'] ?? '');
    $resident_name = $conn->real_escape_string($_POST['resident_name'] ?? '');
    $flat_no = $conn->real_escape_string($_POST['flat_no'] ?? '');
    $designation = $conn->real_escape_string($_POST['designation'] ?? '');
    $institution = $conn->real_escape_string($_POST['institution'] ?? '');
    $department = $conn->real_escape_string($_POST['department'] ?? '');

    // Validate required fields
    if (empty($campus_name) || empty($block_name) || empty($quarter_type) || empty($resident_name) || empty($flat_no) || empty($institution)) {
        $message = "All fields must be filled out.";
    } else {
        // Fetch campus_quarter_id based on campus_name, block_name, and quarter_type
        $sql = "SELECT campus_quarter_id, total_quarters, vacancies, allotted_quarters FROM campus_quarters 
                WHERE campus_name = '$campus_name' AND block_name = '$block_name' AND type = '$quarter_type'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $campus_quarters_id = $row['campus_quarter_id'];
            $vacancies = $row['vacancies'];
            $allotted_quarters = $row['allotted_quarters'];

            // Check if there are vacancies available
            if ($vacancies > 0) {
                // Insert new resident
                $sql_update = "UPDATE residents SET name = '$resident_name', flat_no = '$flat_no', designation = '$designation', institution = '$institution' WHERE flat_no = '$flat_no' AND campus_quarter_id = '$campus_quarters_id'";

                if ($conn->query($sql_update) === TRUE) {
                    // Update campus_quarters table
                    $vacancies--;
                    $allotted_quarters++;
                    $sql_update_quarters = "UPDATE campus_quarters SET vacancies = $vacancies, allotted_quarters = $allotted_quarters 
                                            WHERE campus_quarter_id = $campus_quarters_id";
                    if ($conn->query($sql_update_quarters) === TRUE) {
                        // Update admin status in personal_info table (assuming 'name' uniquely identifies the resident)
                        $sql_update_status = "UPDATE personal_info SET admin_status = ? WHERE fac_id_fk = ?";
                        $stmt = $conn->prepare($sql_update_status);
                        if ($stmt === false) {
                            die('Error preparing the query: ' . $conn->error);  // Display error if query preparation fails
                        }

                        $admin_status = 'Approved';
                        $stmt->bind_param('ss', $admin_status, $fac_id_fk); // Use 'ss' for string and string (assuming fac_id_fk is a string)
                        if ($stmt->execute()) {
                            $message = "Resident approved and all records updated successfully.";
                            echo "<p>$message</p>";
                            echo "<p>Redirecting to dashboard...</p>";
                            echo "<meta http-equiv='refresh' content='3;url=dashboard.php'>";  // Redirect after 3 seconds
                            exit();
                        } else {
                            $message = "Error updating personal_info table: " . $stmt->error;
                            echo "<p>$message</p>"; // Display error if query execution fails
                        }
                        $stmt->close();
                    } else {
                        $message = "Error updating campus_quarters table: " . $conn->error;
                    }
                } else {
                    $message = "Error inserting resident data: " . $conn->error;
                }
            } else {
                $message = "No vacancies available in the specified building.";
            }
        } else {
            $message = "No matching campus quarters found for the provided campus name, block name, and quarter type.";
        }
    }
}

// Handle AJAX requests
if (isset($_GET['action'])) {
    if ($_GET['action'] === 'get_blocks') {
        $campus_name = $_GET['campus_name'] ?? '';
        $blocks = [];
        if ($campus_name) {
            $sql = "SELECT DISTINCT block_name FROM campus_quarters WHERE campus_name = '$campus_name'";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                $blocks[] = $row;
            }
        }
        echo json_encode($blocks);
        exit;
    }

    if ($_GET['action'] === 'get_quarter_types') {
        $campus_name = $_GET['campus_name'] ?? '';
        $block_name = $_GET['block_name'] ?? '';
        $types = [];
        if ($campus_name && $block_name) {
            $sql = "SELECT DISTINCT type FROM campus_quarters WHERE campus_name = '$campus_name' AND block_name = '$block_name'";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                $types[] = $row;
            }
        }
        echo json_encode($types);
        exit;
    }

    if ($_GET['action'] === 'get_flats') {
        $campus_name = $_GET['campus_name'] ?? '';
        $block_name = $_GET['block_name'] ?? '';
        $quarter_type = $_GET['type'] ?? '';
        $flats = [];
        if ($campus_name && $block_name && $quarter_type) {
            $sql = "SELECT flat_no FROM residents 
                    INNER JOIN campus_quarters ON residents.campus_quarter_id = campus_quarters.campus_quarter_id
                    WHERE campus_quarters.campus_name = '$campus_name' AND campus_quarters.block_name = '$block_name' AND campus_quarters.type = '$quarter_type'";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                $flats[] = $row;
            }
        }
        echo json_encode($flats);
        exit;
    }
}

// Fetch campuses for dropdown
$campuses = $conn->query("SELECT DISTINCT campus_name FROM campus_quarters");
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Resident</title>
    <style>

        /* Container for the form */
        .form-container {
            max-width: 1500px;
            margin: 10px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        /* Form field style */
        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group select,
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group button {
            width: 100%;
            padding: 12px;
            background-color: purple;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .form-group button:hover {
            background-color: #45a049;
        }

        /* Message styling */
        .message {
            margin-top: 20px;
            padding: 12px;
            border-radius: 5px;
            font-weight: bold;
        }

        .message.success {
            background-color: #4CAF50;
            color: white;
        }

        .message.error {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>

<body>
<?php include_once('../admin_l1/sidebar.php'); ?>

<main class="main-content">
    <div class="form-container">
        <h2>Update Resident</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="campus_name">Campus Name</label>
                <select id="campus_name" name="campus_name" required>
                    <option value="">Select Campus</option>
                    <?php while ($row = $campuses->fetch_assoc()): ?>
                        <option value="<?php echo $row['campus_name']; ?>" <?php echo ($row['campus_name'] === $campus_name) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($row['campus_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="block_name">Block Name</label>
                <select id="block_name" name="block_name" required>
                    <option value="">Select Block</option>
                </select>
            </div>

            <div class="form-group">
                <label for="quarter_type">Quarter Type</label>
                <select id="quarter_type" name="quarter_type" required>
                    <option value="">Select Quarter Type</option>
                </select>
            </div>

            <div class="form-group">
                <label for="flat_no">Flat No</label>
                <select id="flat_no" name="flat_no" required>
                    <option value="">Select Flat</option>
                </select>
            </div>

            <div class="form-group">
                <label for="resident_name">Resident Name</label>
                <input type="text" id="resident_name" name="resident_name" value="<?php echo htmlspecialchars($resident_name); ?>" required>
            </div>

            <div class="form-group">
                <label for="designation">Designation</label>
                <input type="text" id="designation" name="designation" value="<?php echo htmlspecialchars($designation); ?>" required>
            </div>

            <div class="form-group">
                <label for="institution">Institution</label>
                <input type="text" id="institution" name="institution" value="<?php echo htmlspecialchars($institution); ?>" required>
            </div>

            <div class="form-group">
                <label for="department">Department</label>
                <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($department); ?>" required>
            </div>

            <div class="form-group">
                <input type="hidden" name="fac_id_fk" value="<?php echo htmlspecialchars($fac_id_fk); ?>">
                <button type="submit">Submit</button>
            </div>

            <?php if ($message): ?>
                <div class="message <?php echo strpos($message, 'Error') === false ? 'success' : 'error'; ?>"><?php echo $message; ?></div>
            <?php endif; ?>
        </form>
    </div>
</main>
    <script>
        document.getElementById('campus_name').addEventListener('change', function() {
            var campusName = this.value;
            var blockSelect = document.getElementById('block_name');
            var quarterSelect = document.getElementById('quarter_type');
            var flatSelect = document.getElementById('flat_no');

            blockSelect.innerHTML = '<option value="">Select Block</option>';
            quarterSelect.innerHTML = '<option value="">Select Quarter Type</option>';
            flatSelect.innerHTML = '<option value="">Select Flat</option>';

            if (campusName) {
                fetch(`?action=get_blocks&campus_name=${encodeURIComponent(campusName)}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(block => {
                            var option = document.createElement('option');
                            option.value = block.block_name;
                            option.textContent = block.block_name;
                            blockSelect.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching blocks:', error));
            }
        });

        document.getElementById('block_name').addEventListener('change', function() {
            var campusName = document.getElementById('campus_name').value;
            var blockName = this.value;
            var quarterSelect = document.getElementById('quarter_type');
            var flatSelect = document.getElementById('flat_no');

            quarterSelect.innerHTML = '<option value="">Select Quarter Type</option>';
            flatSelect.innerHTML = '<option value="">Select Flat</option>';

            if (campusName && blockName) {
                fetch(`?action=get_quarter_types&campus_name=${encodeURIComponent(campusName)}&block_name=${encodeURIComponent(blockName)}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(type => {
                            var option = document.createElement('option');
                            option.value = type.type;
                            option.textContent = type.type;
                            quarterSelect.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching quarter types:', error));
            }
        });

        document.getElementById('quarter_type').addEventListener('change', function() {
            var campusName = document.getElementById('campus_name').value;
            var blockName = document.getElementById('block_name').value;
            var quarterType = this.value;
            var flatSelect = document.getElementById('flat_no');

            flatSelect.innerHTML = '<option value="">Select Flat</option>';

            if (campusName && blockName && quarterType) {
                fetch(`?action=get_flats&campus_name=${encodeURIComponent(campusName)}&block_name=${encodeURIComponent(blockName)}&type=${encodeURIComponent(quarterType)}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(flat => {
                            var option = document.createElement('option');
                            option.value = flat.flat_no;
                            option.textContent = flat.flat_no;
                            flatSelect.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching flats:', error));
            }
        });
    </script>

</body>

</html>
