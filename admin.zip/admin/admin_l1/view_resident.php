<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname, $port );

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Default SQL query (no search filter) with JOIN
$sql = "SELECT r.resident_id, r.name, r.flat_no, r.designation, r.institution, r.department, r.campus_quarter_id, 
               cq.campus_name, cq.block_name, cq.type
        FROM residents r
        LEFT JOIN campus_quarters cq ON r.campus_quarter_id = cq.campus_quarter_id";

// Check if the search form is submitted
if (isset($_POST['search'])) {
    $searchTerm = mysqli_real_escape_string($conn, $_POST['search_term']);
    // Modify query to include WHERE condition based on the search term (search by resident name)
    $sql .= " WHERE r.name LIKE '%$searchTerm%'"; // You can also search by other columns if needed
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SQMS</title>
    <style>
        /* Main theme colors and settings */
        :root {
            --primary-color: purple;
            --secondary-color: purple;
            --background-color: #f0f0f0;
            --white: #ffffff;
            --gray: #333333;
            --light-gray: #e0e0e0;
            --table-border-color: #ddd;
            --table-row-hover: #f5f5f5;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: var(--background-color);
            color: var(--gray);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 300px;
            background-color: var(--primary-color);
            color: var(--white);
            padding: 1rem;
        }

        .sidebar h1 {
            font-size: 1.5rem;
            margin-bottom: 2rem;
            text-align: center;
        }

        .nav-menu {
            list-style-type: none;
        }

        .nav-menu li {
            margin-bottom: 1rem;
        }

        .nav-menu a {
            color: var(--white);
            text-decoration: none;
            font-weight: bold;
            display: block;
            padding: 0.5rem;
            transition: background-color 0.3s ease;
        }

        .nav-menu a:hover,
        .nav-menu a.active {
            background-color: var(--secondary-color);
        }

        .main-content {
            flex-grow: 1;
            padding: 2rem;
            overflow-y: auto;
        }

        .dashboard-section {
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            display: inline-block;
        }

        .search-container {
            display: inline-block;
            float: right;
        }

        .search-container input {
            padding: 0.5rem;
            font-size: 1rem;
            border: 1px solid var(--light-gray);
            border-radius: 4px;
        }

        .search-container button {
            padding: 0.5rem 1rem;
            background-color: var(--primary-color);
            color: var(--white);
            font-size: 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: var(--secondary-color);
        }

        h3 {
            color: var(--secondary-color);
            margin-top: 2rem;
            margin-bottom: 1rem;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
            font-size: 1rem;
        }

        th, td {
            padding: 0.75rem;
            text-align: left;
            border: 1px solid var(--table-border-color);
        }

        th {
            background-color: var(--primary-color);
            color: #ffffff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: var(--table-row-hover);
        }
    </style>
</head>

<body>
<?php include_once('../admin_l1/sidebar.php'); ?>

    <main class="main-content">
        <section class="dashboard-section">
            <h2>Residents List</h2>
            
            <!-- Search Form -->
            <div class="search-container">
                <form action="" method="POST">
                    <input type="text" name="search_term" placeholder="Search by Resident Name" required>
                    <button type="submit" name="search">Search</button>
                </form>
            </div>

            <?php
            if ($result->num_rows > 0) {
                echo "<table>";
                echo "<tr>
                        <th>Resident ID</th>
                        <th>Name</th>
                        <th>Campus Name</th>
                        <th>Block Name</th>
                        <th>Flat No.</th>
                        <th>Designation</th>
                        <th>Institution</th>  
                        <th>Type</th>
                      </tr>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['resident_id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['campus_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['block_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['flat_no']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['designation']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['institution']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['type']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No data found in residents table.</p>";
            }

            // Close the database connection
            $conn->close();
            ?>
        </section>
    </main>
</body>
</html>
