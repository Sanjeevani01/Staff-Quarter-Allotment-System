<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

$maintenance_query = "SELECT * FROM maintenance WHERE status='Completed' ORDER BY maintenance_id ASC";
$maintenance_result = $conn->query($maintenance_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Requests - SQMS</title>
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">

    <link rel="stylesheet" href="../css/forms.css">
    <style>
        .delete-btn {
            background-color: #dc3545;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .delete-btn:hover {
            background-color: #e0a800;
        }

        .update-btn {
            background-color: #007bff;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .update-btn:hover {
            background-color: #007bff;
        }
    </style>
    <script>
        function updateStatus(id, status) {
            fetch('update_status.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'id=' + id + '&status=' + status
            })
                .then(response => response.text())
                .then(data => {
                    if (data === 'success') {
                        document.getElementById('row-' + id).remove();
                    } else {
                        alert('Failed to update status');
                    }
                });
        }
    </script>
</head>

<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>

    <main class="main-content">
        <section class="dashboard-section">
            <h1>Completed Maintenance Requests</h1>

            <?php if (!empty($message)): ?>
                <div id="message" class="message">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <?php if ($maintenance_result && $maintenance_result->num_rows > 0): ?>
                <table class="residents-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Campus Name</th>
                            <th>Block Name</th>
                            <th>Type</th>
                            <th>Flat No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Date</th>
                            <th>Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $maintenance_result->fetch_assoc()): ?>
                            <tr id="row-<?php echo $row['maintenance_id']; ?>">
                                <td><?php echo htmlspecialchars($row['maintenance_id']); ?></td>
                                <td><?php echo htmlspecialchars($row['campus_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['block_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['quarter_type']); ?></td>
                                <td><?php echo htmlspecialchars($row['flat_no']); ?></td>
                                <td><?php echo htmlspecialchars($row['resident_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['request_date']); ?></td>
                                <td><?php echo htmlspecialchars($row['maintenance_reason']); ?></td>

                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-message">
                    No pending maintenance requests found.
                </div>
            <?php endif; ?>
        </section>
    </main>
</body>

</html>

<?php
$conn->close();
?>