<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<?php
// Database connection
$servername = "localhost";
$username = "root"; // Update as per your database setup
$password = ""; // Update as per your database setup
$dbname = "sqms"; // Database name
$port = 3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from URL parameters
$resident_name = $_GET['name'] ?? '';
$designation = $_GET['designation'] ?? '';
$department = $_GET['department'] ?? '';
$institute = $_GET['institute'] ?? '';
$campus_name = $_GET['campus_name'] ?? ''; // Pass campus_name via URL
$block_id = $_GET['block_id'] ?? ''; // Pass block_id via URL
$flat_no = $_GET['flat_no'] ?? ''; // Pass flat_no via URL

// Ensure required parameters are available
if (empty($resident_name) || empty($designation) || empty($department) || empty($campus_name) || empty($block_id) || empty($flat_no)) {
    die("Required data is missing.");
}

// Fetch campus_quarters_id
$sql = "SELECT campus_quarter_id, total_quarters, vacancies, allotted_quarters FROM campus_quarters WHERE campus_name = '$campus_name' AND block_id = '$block_id'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $campus_quarters_id = $row['campus_quarters_id'];
    $total_quarters = $row['total_quarters'];
    $vacancies = $row['vacancies'];
    $allotted_quarters = $row['allotted_quarters'];

    // Check if there are vacancies available
    if ($vacancies > 0) {
        // Insert new resident
        $sql_insert = "INSERT INTO residents (name, flat_no, designation, institution, campus_quarter_id) 
                        VALUES ('$resident_name', '$flat_no', '$designation', '$department', $campus_quarters_id)";
        if ($conn->query($sql_insert) === TRUE) {
            // Update campus_quarters table
            $vacancies--;
            $allotted_quarters++;
            $sql_update_quarters = "UPDATE campus_quarters SET vacancies = $vacancies, allotted_quarters = $allotted_quarters 
                                    WHERE campus_quarters_id = $campus_quarters_id";
            if ($conn->query($sql_update_quarters) === TRUE) {
                // Update admin status in personal_info table (assuming you have an identifier)
                $sql_update_status = "UPDATE personal_info SET admin_status = 'Approved' WHERE name = '$resident_name'";
                if ($conn->query($sql_update_status) === TRUE) {
                    echo "Resident approved and all records updated successfully.";
                } else {
                    echo "Error updating personal_info table: " . $conn->error;
                }
            } else {
                echo "Error updating campus_quarters table: " . $conn->error;
            }
        } else {
            echo "Error inserting resident data: " . $conn->error;
        }
    } else {
        echo "No vacancies available in the specified building.";
    }
} else {
    echo "No matching campus quarters found for the provided campus name and block ID.";
}

$conn->close();
?>
