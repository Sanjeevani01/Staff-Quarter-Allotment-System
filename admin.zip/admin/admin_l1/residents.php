<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port );

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Handle update
if (isset($_POST['delete_resident'])) {
    $resident_id = $_POST['resident_id'];

    // Get campus_quarter_id for the resident's flat
    $get_campus_query = "SELECT campus_quarter_id FROM residents WHERE resident_id = ?";
    $stmt = $conn->prepare($get_campus_query);
    $stmt->bind_param("i", $resident_id);
    $stmt->execute();
    $stmt->bind_result($campus_quarter_id);
    $stmt->fetch();
    $stmt->close();

    // Check if any of the fields are non-empty before proceeding
    $check_fields_query = "SELECT name, email, designation, department, institute FROM residents WHERE resident_id = ?";
    $stmt = $conn->prepare($check_fields_query);
    $stmt->bind_param("i", $resident_id);
    $stmt->execute();
    $stmt->bind_result($name, $email, $designation, $department, $institute);
    $stmt->fetch();
    $stmt->close();

    if ($name !== '' || email == '' || $designation !== '' || $department !== '' || $institute !== '') {
        // Begin transaction to ensure both updates are atomic
        $conn->begin_transaction();

        try {
            // Update residents table: Reset fields to blank
            $update_resident_query = "UPDATE residents SET name = '',email = '', designation = '', department = '', institute = '' WHERE resident_id = ?";
            $stmt = $conn->prepare($update_resident_query);
            $stmt->bind_param("i", $resident_id);
            $stmt->execute();
            $stmt->close();

            // Update campus_quarters table
            $update_quarters_query = "UPDATE campus_quarters SET vacancies = vacancies + 1, allotted_quarters = allotted_quarters - 1 WHERE campus_quarter_id = ?";
            $stmt = $conn->prepare($update_quarters_query);
            $stmt->bind_param("i", $campus_quarter_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            $message = "Resident details reset and campus quarter updated successfully!";
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error resetting resident details and updating campus quarter: " . $e->getMessage();
        }
    } else {
        $message = "Resident details are already blank. No update was performed.";
    }

}

// Search functionality for flat number
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
// $residents_query = "SELECT resident_id, flat_no, name, designation, institute FROM residents";
$residents_query = "SELECT r.resident_id, r.name, r.flat_no, r.designation, r.department, r.institute, r.campus_quarter_id, 
               cq.campus_name, cq.block_name, cq.type
        FROM residents r
        LEFT JOIN campus_quarters cq ON r.campus_quarter_id = cq.campus_quarter_id";
if (!empty($search)) {
    $residents_query .= " WHERE r.name LIKE '%$search%'";
}
$residents_query .= " ORDER BY r.resident_id ASC";
$residents_result = $conn->query($residents_query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Resident Details - SQMS</title>
    <link rel="stylesheet" href="../css/forms.css">
    <style>
        /* Your original styling */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #4B0082;
            margin-bottom: 20px;
        }

        .search-container {
            display: flex;
            align-items: center;
        }

        .search-container input {
            padding: 0.5rem;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .search-container button {
            padding: 0.5rem 1rem;
            background-color: purple;
            color: white;
            font-size: 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-left: 0.5rem;
        }

        .search-container button:hover {
            background-color: #5A2A7B;
        }

        .delete-btn {
            background-color: #dc3545;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .delete-btn:hover {
            background-color: #e0a800;
        }

        .update-btn {
            background-color: #007bff;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .update-btn:hover {
            background-color: #007bff;
        }
        .add-residents-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .add-residents-btn {
            background-color: purple;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
        }

        .add-residents-btn a {
            text-decoration: none;
            color: white;
        }

        .add-residents-btn:hover {
            background-color: #5A2A7B;
        }
    </style>
</head>

<body>
    
        <?php include_once('../admin_l1/sidebar.php'); ?>
    

    <main class="main-content">
        <section class="dashboard-section">
            <!-- Title and search bar aligned opposite to each other -->
            <div class="section-header">
                <h1>Update Resident Details</h1>
                <div class="search-container">
                    <form action="" method="GET">
                        <input type="text" placeholder="Search by flat number" name="search"
                            value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                        <button type="submit">Search</button>
                    </form>
                </div>
            </div>

            <!-- Display message if any -->
            <?php if (!empty($message)): ?>
                <div id="message" class="message">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- Table with data -->
            <?php if ($residents_result && $residents_result->num_rows > 0): ?>
                <table class="residents-table">
                    <thead>
                        <tr>
                            <th>Resident ID</th>
                            <th>Flat No.</th>
                            <th>Name</th>
                            <th>Cmapus Name</th>
                            <th>Block Name</th>
                            <th>Designation</th>
                            <th>Department</th>
                            <th>Institution</th>
                            <th>Type</th>
                            <th>Action</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $residents_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['resident_id']); ?></td>
                                <td><?php echo htmlspecialchars($row['flat_no']); ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['campus_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['block_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['designation']); ?></td>
                                <td><?php echo htmlspecialchars($row['department']); ?></td>
                                <td><?php echo htmlspecialchars($row['institute']); ?></td>
                                <td><?php echo htmlspecialchars($row['type']); ?></td>
                                <td>
                                    <form method="GET" action="update_resident.php">
                                        <input type="hidden" name="resident_id" value="<?php echo $row['resident_id']; ?>">
                                        <button type="submit" class="update-btn">Update</button>
                                    </form>
                                </td>

                                <td>
                                    <form method="POST" onsubmit="return confirmUpdate();">
                                        <input type="hidden" name="resident_id" value="<?php echo $row['resident_id']; ?>">
                                        <button type="submit" name="delete_resident" class="delete-btn">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-message">
                    No residents found in the database.
                </div>
            <?php endif; ?>
        </section>
        <div class="add-residents-container">
            <button class="add-residents-btn"><a href="add_resident.php">Add Resident</a></button>
        </div>
    </main>
</body>

</html>

<?php
$conn->close();
?>