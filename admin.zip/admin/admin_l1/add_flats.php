<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php");
    exit();
}
?>

<?php
$message = "";

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$create_residents_table = "
    CREATE TABLE IF NOT EXISTS residents (
        resident_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100),
        flat_no VARCHAR(50) NOT NULL,
        designation VARCHAR(100),
        department VARCHAR(100),
        institute VARCHAR(100),
        campus_quarter_id INT NOT NULL,
        FOREIGN KEY (campus_quarter_id) REFERENCES campus_quarters(campus_quarter_id)
    )
";

if ($conn->query($create_residents_table) !== TRUE) {
    die("Error creating residents table: " . $conn->error);
}


// Fetch distinct campus names for the dropdown
$sql = "SELECT DISTINCT campus_name FROM campus_quarters";
$result = $conn->query($sql);

$campusNames = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $campusNames[] = $row['campus_name'];
    }
}

// Handle form submission to add a resident
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['flat_no'])) {
    $campus_name = $_POST['campus_name'];
    $block_name = $_POST['block_name'];
    $quarter_type = $_POST['quarter_type'];
    $flat_no = $_POST['flat_no'];

    $sql = "SELECT campus_quarter_id, total_quarters, vacancies FROM campus_quarters WHERE campus_name = ? AND block_name = ? AND type = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $campus_name, $block_name, $quarter_type);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $campus_quarter = $result->fetch_assoc();
        $campus_quarter_id = $campus_quarter['campus_quarter_id'];
        $vacancies = $campus_quarter['vacancies'];
        $total_quarters = $campus_quarter['total_quarters'];

        $stmt = $conn->prepare("INSERT INTO residents (flat_no, campus_quarter_id) VALUES (?, ?)");
        $stmt->bind_param("si", $flat_no, $campus_quarter_id);

        if ($stmt->execute()) {
            $vacancies++;
            $total_quarters++;
            $update_sql = "UPDATE campus_quarters SET vacancies = ?, total_quarters = ? WHERE campus_quarter_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("iii", $vacancies, $total_quarters, $campus_quarter_id);

            if ($update_stmt->execute()) {
                $message = "Flat added successfully! Vacancy and total quarters updated.";
            } else {
                $message = "Error updating counts: " . $update_stmt->error;
            }

            $update_stmt->close();
        } else {
            $message = "Error adding resident: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $message = "No matching campus, block, or quarter type found.";
    }
}

// Handle AJAX request to fetch blocks and quarter types
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['campus_name']) && !isset($_POST['flat_no'])) {
    $campus_name = $_POST['campus_name'];
    $block_name = $_POST['block_name'] ?? '';

    if (empty($block_name)) {
        $sql = "SELECT DISTINCT block_name FROM campus_quarters WHERE campus_name = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $campus_name);
        $stmt->execute();
        $result = $stmt->get_result();

        $blocks = [];
        while ($row = $result->fetch_assoc()) {
            $blocks[] = $row['block_name'];
        }

        echo json_encode(['blocks' => $blocks]);
        exit;
    }

    $sql = "SELECT DISTINCT type FROM campus_quarters WHERE campus_name = ? AND block_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $campus_name, $block_name);
    $stmt->execute();
    $result = $stmt->get_result();

    $quarterTypes = [];
    while ($row = $result->fetch_assoc()) {
        $quarterTypes[] = $row['type'];
    }

    echo json_encode(['quarter_types' => $quarterTypes]);
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Resident</title>
    <link rel="stylesheet" href="../css/forms.css">
    <style>
        .form-container {
            max-width: 1300px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            margin-bottom: 20px;
            text-align: left;
            color: purple;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: purple;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
        }

        .form-group button:hover {
            background-color: #4a148c;
        }

        .message {
            margin-top: 15px;
            font-size: 14px;
            color: #333;
            text-align: center;
        }

        .message.success {
            color: #4CAF50;
        }

        .message.error {
            color: #f44336;
        }
    </style>
</head>

<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>

    <main class="main-content">
        <div class="form-container">
            <h2>Add Flat</h2>
            <form action="" method="POST" id="residentForm">
                <div class="form-group">
                    <label for="campus_name">Campus Name:</label>
                    <select id="campus_name" name="campus_name" required onchange="fetchBlocks()">
                        <option value="">Select Campus</option>
                        <?php foreach ($campusNames as $name): ?>
                            <option value="<?= htmlspecialchars($name) ?>"><?= htmlspecialchars($name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="block_name">Block Name:</label>
                    <select id="block_name" name="block_name" required onchange="fetchQuarterTypes()">
                        <option value="">Select Block</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="quarter_type">Quarter Type:</label>
                    <select id="quarter_type" name="quarter_type" required>
                        <option value="">Select Quarter Type</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="flat_no">Flat Number:</label>
                    <input type="text" id="flat_no" name="flat_no" required>
                </div>
                <div class="form-group">
                    <button type="submit">Add Flat</button>
                </div>
            </form>
            <?php if ($message): ?>
                <div class="message <?= strpos($message, 'Error') !== false ? 'error' : 'success'; ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script>
        function fetchBlocks() {
            const campusName = document.getElementById('campus_name').value;
            const blockSelect = document.getElementById('block_name');
            const quarterSelect = document.getElementById('quarter_type');

            blockSelect.innerHTML = '<option value="">Select Block</option>';
            quarterSelect.innerHTML = '<option value="">Select Quarter Type</option>';

            if (campusName) {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const data = JSON.parse(xhr.responseText);
                        data.blocks.forEach(block => {
                            const option = document.createElement('option');
                            option.value = block;
                            option.textContent = block;
                            blockSelect.appendChild(option);
                        });
                    }
                };

                xhr.send("campus_name=" + encodeURIComponent(campusName));
            }
        }

        function fetchQuarterTypes() {
            const campusName = document.getElementById('campus_name').value;
            const blockName = document.getElementById('block_name').value;
            const quarterSelect = document.getElementById('quarter_type');

            quarterSelect.innerHTML = '<option value="">Select Quarter Type</option>';

            if (campusName && blockName) {
                const xhr = new XMLHttpRequest();
                xhr.open("POST", "", true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const data = JSON.parse(xhr.responseText);
                        data.quarter_types.forEach(type => {
                            const option = document.createElement('option');
                            option.value = type;
                            option.textContent = type;
                            quarterSelect.appendChild(option);
                        });
                    }
                };

                xhr.send(`campus_name=${encodeURIComponent(campusName)}&block_name=${encodeURIComponent(blockName)}`);
            }
        }
        document.getElementById('flat_no').addEventListener('input', function(event) {
            const flatNoInput = event.target;
            const flatNo = flatNoInput.value;

            // Regular expression to allow only numbers
            const isValid = /^[0-9]*$/.test(flatNo);

            if (!isValid) {
                // If the input is not valid (contains anything other than numbers), remove the last entered character
                flatNoInput.value = flatNo.slice(0, -1);
                alert("Please enter only numbers for Flat Number.");
            }
        });

        // Optional: You can add the function to check if the field is empty when submitting
        document.getElementById('residentForm').addEventListener('submit', function(event) {
            const flatNo = document.getElementById('flat_no').value;
            if (!/^\d+$/.test(flatNo)) {
                alert("Flat number should only contain digits.");
                event.preventDefault(); // Prevent form submission if validation fails
            }
        });
    </script>
</body>

</html>