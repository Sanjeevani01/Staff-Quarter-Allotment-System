<!-- update_quarter.php -->
<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<?php
// Database connection
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'sqms';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$statusMessage = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $campus_name = $_POST['campus_name'];
    $block_name = $_POST['block_name'];
    $type = $_POST['type'];
    $building = $_POST['building'];
    $total_quarters = $_POST['total_quarters'];
    $allotted_quarters = $_POST['allotted_quarters'];
    $vacancies = $_POST['vacancies'];
    $remarks = $_POST['remarks'];

    // Initialize the update query and parameters
    $updateFields = [];
    $updateParams = [];
    $paramTypes = '';

    // Conditionally add fields to the update query if they are set
    if (isset($building) && $building !== '') {
        $updateFields[] = "building = ?";
        $updateParams[] = $building;
        $paramTypes .= 's';
    }
    if (isset($total_quarters) && $total_quarters !== '') {
        $updateFields[] = "total_quarters = ?";
        $updateParams[] = $total_quarters;
        $paramTypes .= 'i';
    }
    if (isset($allotted_quarters) && $allotted_quarters !== '') {
        $updateFields[] = "allotted_quarters = ?";
        $updateParams[] = $allotted_quarters;
        $paramTypes .= 'i';
    }
    if (isset($vacancies) && $vacancies !== '') {
        $updateFields[] = "vacancies = ?";
        $updateParams[] = $vacancies;
        $paramTypes .= 'i';
    }
    if (isset($remarks) && $remarks !== '') {
        $updateFields[] = "remarks = ?";
        $updateParams[] = $remarks;
        $paramTypes .= 's';
    }

    // Only proceed if there are fields to update
    if (!empty($updateFields)) {
        // Add WHERE conditions and bind their values
        $updateQuery = "UPDATE campus_quarters SET " . implode(', ', $updateFields) . " WHERE campus_name = ? AND block_name = ? AND type = ?";
        $stmt = $conn->prepare($updateQuery);

        // Bind the parameters
        $paramTypes .= 'sss';
        $updateParams[] = $campus_name;
        $updateParams[] = $block_name;
        $updateParams[] = $type;

        // Use the unpacking operator (...) to pass array elements as individual arguments
        $stmt->bind_param($paramTypes, ...$updateParams);

        if ($stmt->execute()) {
            echo "<p>$statusMessage</p>";
            echo "<p>Redirecting to dashboard...</p>";
            echo "<meta http-equiv='refresh' content='3;url=view_quarter.php'>";
        } else {
            $statusMessage = "Error updating record: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "No fields to update.";
    }
    exit;
}

// AJAX request handling for dropdowns
if (isset($_GET['action'])) {
    // Get blocks for a given campus
    if ($_GET['action'] == 'get_blocks' && isset($_GET['campus_name'])) {
        $campus_name = $_GET['campus_name'];
        $blockQuery = "SELECT DISTINCT block_name FROM campus_quarters WHERE campus_name = '$campus_name'";
        $blockResult = $conn->query($blockQuery);
        $blocks = [];
        while ($row = $blockResult->fetch_assoc()) {
            $blocks[] = $row;
        }
        echo json_encode($blocks);
    }

    // Get quarter types for a given block and campus
    if ($_GET['action'] == 'get_quarter_types' && isset($_GET['campus_name']) && isset($_GET['block_name'])) {
        $campus_name = $_GET['campus_name'];
        $block_name = $_GET['block_name'];
        $typeQuery = "SELECT DISTINCT type FROM campus_quarters WHERE campus_name = '$campus_name' AND block_name = '$block_name'";
        $typeResult = $conn->query($typeQuery);
        $types = [];
        while ($row = $typeResult->fetch_assoc()) {
            $types[] = $row;
        }
        echo json_encode($types);
    }
    exit;
}

// Initial campus dropdown query
$campusQuery = "SELECT DISTINCT campus_name FROM campus_quarters";
$campusResult = $conn->query($campusQuery);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Campus Quarters</title>
    <link rel="stylesheet" href="../css/forms.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <style>

        .form-container h2 {
            margin-bottom: 20px;
            color: purple;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: purple;
            border: none;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        .form-group button:hover {
            background-color: #5a3d82;
        }

        .message {
            margin-top: 20px;
            color: green;
        }
    </style>
</head>

<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>

    <main class="main-content">
        <section id="view-forms" class="dashboard-section">
            <div class="main-container">
                <div class="form-container">
                    <h2>Update Campus Quarters</h2>
                    <form method="post" action="">
                        <!-- Campus Name Dropdown -->
                        <div class="form-group">
                            <label for="campus_name">Campus Name:</label>
                            <select name="campus_name" id="campus_name" required>
                                <option value="">Select Campus</option>
                                <?php while ($campusRow = $campusResult->fetch_assoc()): ?>
                                    <option value="<?= $campusRow['campus_name'] ?>"><?= $campusRow['campus_name'] ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <!-- Block Name Dropdown -->
                        <div class="form-group">
                            <label for="block_name">Block Name:</label>
                            <select name="block_name" id="block_name" required>
                                <option value="">Select Block</option>
                            </select>
                        </div>

                        <!-- Quarter Type Dropdown -->
                        <div class="form-group">
                            <label for="type">Quarter Type:</label>
                            <select name="type" id="type" required>
                                <option value="">Select Quarter Type</option>
                            </select>
                        </div>

                        <!-- Other Input Fields -->
                        <div class="form-group">
                            <label for="building">Building:</label>
                            <input type="text" name="building" id="building">
                        </div>

                        <div class="form-group">
                            <label for="total_quarters">Total Quarters:</label>
                            <input type="number" name="total_quarters" id="total_quarters">
                        </div>

                        <div class="form-group">
                            <label for="allotted_quarters">Allotted Quarters:</label>
                            <input type="number" name="allotted_quarters" id="allotted_quarters">
                        </div>

                        <div class="form-group">
                            <label for="vacancies">Vacancies:</label>
                            <input type="number" name="vacancies" id="vacancies">
                        </div>

                        <div class="form-group">
                            <label for="remarks">Remarks:</label>
                            <input type="text" name="remarks" id="remarks">
                        </div>

                        <div class="form-group">
                            <button type="submit">Update</button>
                        </div>
                    </form>

                    <?php if ($statusMessage): ?>
                        <div class="message">
                            <p><?= htmlspecialchars($statusMessage); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>

    <script>
        document.getElementById('campus_name').addEventListener('change', function () {
            var campusName = this.value;
            var blockSelect = document.getElementById('block_name');
            var typeSelect = document.getElementById('type');

            blockSelect.innerHTML = '<option value="">Select Block</option>';
            typeSelect.innerHTML = '<option value="">Select Quarter Type</option>';

            if (campusName) {
                fetch(`?action=get_blocks&campus_name=${encodeURIComponent(campusName)}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(block => {
                            var option = document.createElement('option');
                            option.value = block.block_name;
                            option.textContent = block.block_name;
                            blockSelect.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching blocks:', error));
            }
        });

        document.getElementById('block_name').addEventListener('change', function () {
            var campusName = document.getElementById('campus_name').value;
            var blockName = this.value;
            var typeSelect = document.getElementById('type');

            typeSelect.innerHTML = '<option value="">Select Quarter Type</option>';

            if (campusName && blockName) {
                fetch(`?action=get_quarter_types&campus_name=${encodeURIComponent(campusName)}&block_name=${encodeURIComponent(blockName)}`)
                    .then(response => response.json())
                    .then(data => {
                        data.forEach(type => {
                            var option = document.createElement('option');
                            option.value = type.type;
                            option.textContent = type.type;
                            typeSelect.appendChild(option);
                        });
                    })
                    .catch(error => console.error('Error fetching quarter types:', error));
            }
        });
    </script>
</body>

</html>

<?php $conn->close();?>


