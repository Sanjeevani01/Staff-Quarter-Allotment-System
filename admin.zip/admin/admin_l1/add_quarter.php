<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port );

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the table if it doesn't exist
$table_creation_query = "CREATE TABLE IF NOT EXISTS campus_quarters (
    campus_quarters_id INT AUTO_INCREMENT PRIMARY KEY,
    block_name VARCHAR(255) NOT NULL,
    type VARCHAR(100),
    building VARCHAR(100),
    total_quarters INT NOT NULL,
    allotted_quarters INT NOT NULL,
    vacancies INT NOT NULL,
    campus_name VARCHAR(255),
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($table_creation_query) === TRUE) {
    // echo "Table CampusQuarters checked/created successfully.<br>";
} else {
    echo "Error creating table: " . $conn->error . "<br>";
}

$message = "";  // Variable to hold the echo message

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture Campus Quarters Data from the form
    $block_name = $_POST['block_name'];
    $type = $_POST['type'];
    $building = $_POST['building'];
    $total_quarters = $_POST['total_quarters'];
    $allotted_quarters = $_POST['allotted_quarters'];
    $vacancies = $_POST['vacancies'];
    $campus_name = $_POST['campus_name'];
    $remarks = $_POST['remark'];

    // Insert into CampusQuarters table
    $sql = "INSERT INTO campus_quarters (block_name, type, building, total_quarters, allotted_quarters, vacancies, campus_name, remarks)
            VALUES ('$block_name', '$type', '$building', $total_quarters, $allotted_quarters, $vacancies, '$campus_name', '$remarks')";

    if ($conn->query($sql) === TRUE) {
        $campus_quarters_id = $conn->insert_id;  // Get the inserted ID for linking residents
        $message = "New record created successfully in CampusQuarters with ID: " . $campus_quarters_id;
        header("Location: campus_quarter.php");
        exit();

    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="../css/forms.css">
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SQMS</title>
    <script>
        // JavaScript function to hide the message after a certain period (e.g., 3 seconds)
        window.onload = function () {
            setTimeout(function () {
                var messageDiv = document.getElementById('message');
                if (messageDiv) {
                    messageDiv.style.display = 'none'; // Hide the message after 3 seconds
                }
            }, 3000); // 3000 milliseconds = 3 seconds
        };
    </script>

    <style>
        /* body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        } */
        .form-container {
            width: 400px;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group textarea {
            resize: vertical;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: purple;
            border: none;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        .form-group button:hover {
            background-color: purple;
        }
        .error {
            display: none;
            color: red;
            font-size: 14px;
            margin-top: 4px;
        }

        .form-error:empty {
            display: none;
        }

    </style>
</head>

<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>

    <main class="main-content">
        <section id="view-forms" class="dashboard-section">

            <h1 style="color:purple;">Add Quarters</h1>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="campus_name">Campus Name</label>
                <input type="text" id="campus_name" name="campus_name" required oninput="validateCampusName()">
                <div class="error" id="campus_name_error" style="display: none;"></div>
            </div>

            <div class="form-group">
                <label for="block_name">Block Name</label>
                <input type="text" id="block_name" name="block_name" required oninput="validateBlockName()">
                <div class="error" id="block_name_error"style="display: none;"></div>
            </div>

            <div class="form-group">
                <label for="type">Type</label>
                <input type="text" id="type" name="type" required oninput="validateType()">
                <div class="error" id="type_error"style="display: none;"></div>
            </div>

            <div class="form-group">
                <label for="building">Building</label>
                <input type="text" id="building" name="building" required oninput="validateBuilding()">
                <div class="error" id="building_error" style="display: none;"></div>
            </div>

            <div class="form-group">
                <label for="total_quarters">Total Quarters</label>
                <input type="number" id="total_quarters" name="total_quarters" required oninput="validateTotalQuarters()">
                <div class="error" id="total_quarters_error" style="display: none;"></div>
            </div>

            <div class="form-group">
                <label for="allotted_quarters">Allotted Quarters</label>
                <input type="number" id="allotted_quarters" name="allotted_quarters" required oninput="validateAllottedQuarters()">
                <div class="error" id="allotted_quarters_error" style="display: none;"></div>
            </div>

            <div class="form-group">
                <label for="vacancies">Vacancies</label>
                <input type="number" id="vacancies" name="vacancies" required oninput="validateVacancies()">
                <div class="error" id="vacancies_error" style="display: none;"></div>
            </div>

            <div class="form-group">
                <label for="remark">Remark</label>
                <textarea id="remark" name="remark" rows="3" oninput="validateRemark()"></textarea>
                <div class="error" id="remark_error" style="display: none;"></div   >
            </div>
                <div class="form-group">
                    <button type="submit">Submit</button>
                </div>
            </form>
            <!-- Display the message here -->
            <?php if (!empty($message)): ?>
                <div id="message" class="message">
                    <p><?php echo $message; ?></p>
                </div>
            <?php endif; ?>
        </section>
    </main>
    <script>
        function showError(fieldId, message) {
            const errorSpan = document.getElementById(fieldId + "_error");
            errorSpan.textContent = message;
            errorSpan.style.display = "block";
        }

        function hideError(fieldId) {
            const errorSpan = document.getElementById(fieldId + "_error");
            errorSpan.textContent = "";
            errorSpan.style.display = "none";
        }

        function validateCampusName() {
            const input = document.getElementById("campus_name").value.trim();
            if (input === "") {
                showError("campus_name", "Campus Name is required.");
            } else {
                hideError("campus_name");
            }
        }

        function validateBlockName() {
            const input = document.getElementById("block_name").value.trim();
            if (input === "") {
                showError("block_name", "Block Name is required.");
            } else {
                hideError("block_name");
            }
        }

        function validateType() {
            const input = document.getElementById("type").value.trim();
            if (input === "") {
                showError("type", "Type is required.");
            } else {
                hideError("type");
            }
        }

        function validateBuilding() {
            const input = document.getElementById("building").value.trim();
            if (input === "") {
                showError("building", "Building is required.");
            } else {
                hideError("building");
            }
        }

        function validateTotalQuarters() {
            const input = document.getElementById("total_quarters").value.trim();
            if (input === "" || isNaN(input) || Number(input) < 0) {
                showError("total_quarters", "Enter a valid number for Total Quarters.");
            } else {
                hideError("total_quarters");
            }
        }

        function validateAllottedQuarters() {
            const input = document.getElementById("allotted_quarters").value.trim();
            if (input === "" || isNaN(input) || Number(input) < 0) {
                showError("allotted_quarters", "Enter a valid number for Allotted Quarters.");
            } else {
                hideError("allotted_quarters");
            }
        }

        function validateVacancies() {
            const input = document.getElementById("vacancies").value.trim();
            if (input === "" || isNaN(input) || Number(input) < 0) {
                showError("vacancies", "Enter a valid number for Vacancies.");
            } else {
                hideError("vacancies");
            }
        }

    </script>

</body>

</html>