<?php
session_start();

// Check if the user is an Admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sqms";
$port = 3308;

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if `quarter_id` is set
if (!isset($_POST['quarter_id'])) {
    die("Invalid request. Quarter ID is missing.");
}

$quarter_id = $_POST['quarter_id'];
$query = "SELECT * FROM campus_quarters WHERE campus_quarter_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $quarter_id);
$stmt->execute();
$result = $stmt->get_result();
$quarter = $result->fetch_assoc();

if (!$quarter) {
    die("Quarter not found.");
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="../src/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Campus Quarters</title>
    <!-- <link rel="stylesheet" href="../css/forms.css"> -->
     
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .form-container {
            /* max-width: 500px; */
            width: 78%;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            margin-top: 40px;
        }

        .form-container h2 {
            text-align: center;
            color: purple;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: purple;
            border: none;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        .form-group button:hover {
            background-color: #5a3d82;
        }

        .message {
            margin-top: 20px;
            color: green;
            text-align: center;
        }
        .error {
            color: red;
            font-size: 0.9em;
            display: none;
        }
    </style>
</head>

<body>
    <?php include_once('../admin_l1/sidebar.php'); ?>

    <div class="form-container">
        <h2>Update Campus Quarter</h2>
        <form action="process_update_quarter.php" method="POST">
            <input type="hidden" name="quarter_id" value="<?php echo $quarter['campus_quarter_id']; ?>">

            <div class="form-group">
                <label>Campus Name:</label>
                <input type="text" name="campus_name" id="campus_name" value="<?php echo htmlspecialchars($quarter['campus_name']); ?>"
                    required>
                    <div class="error" id="campus_name_error"></div>
            </div>

            <div class="form-group">
                <label>Block Name:</label>
                <input type="text" name="block_name" id="block_name" value="<?php echo htmlspecialchars($quarter['block_name']); ?>"
                    required>
                    <div class="error" id="block_name_error"></div>
            </div>

            <div class="form-group">
                <label>Type:</label>
                <input type="text" name="type" id="type" value="<?php echo htmlspecialchars($quarter['type']); ?>" required>
                <div class="error" id="type_error"></div>
            </div>

            <div class="form-group">
                <label>Total Quarters:</label>
                <input type="number" name="total_quarters" id="total_quarters" value="<?php echo $quarter['total_quarters']; ?>" required>
                <div class="error" id="total_quarters_error"></div>
            </div>

            <div class="form-group">
                <label>Allotted Quarters:</label>
                <input type="number" name="allotted_quarters" id="allotted_quarters" value="<?php echo $quarter['allotted_quarters']; ?>"
                    required>
                    <div class="error" id="allotted_quarters_error"></div>
            </div>

            <div class="form-group">
                <label>Vacancies:</label>
                <input type="number" name="vacancies" id="vacancies" value="<?php echo $quarter['vacancies']; ?>" required>
                <div class="error" id="vacancies_error"></div>
            </div>

            <div class="form-group">
                <button type="submit" name="update_quarter">Update</button>
            </div>
        </form>
    </div>
    <script>
    // Generic function to show errors
    function showError(fieldId, message) {
        const errorSpan = document.getElementById(fieldId + "_error");
        errorSpan.textContent = message;
        errorSpan.style.display = "block";
    }

    // Hide error message
    function hideError(fieldId) {
        const errorSpan = document.getElementById(fieldId + "_error");
        errorSpan.textContent = "";
        errorSpan.style.display = "none";
    }

    // Generic function to validate inputs
    function validateInput(fieldId, conditionFn, errorMessage) {
        const input = document.getElementById(fieldId).value.trim();
        if (!conditionFn(input)) {
            showError(fieldId, errorMessage);
            return false;
        } else {
            hideError(fieldId);
            return true;
        }
    }

    // Validation conditions
    function isNotEmpty(input) {
        return input !== "";
    }

    function isPositiveNumber(input) {
        return !isNaN(input) && Number(input) >= 0;
    }

    // Field-specific validation functions
    function validateCampusName() {
        return validateInput("campus_name", isNotEmpty, "Campus Name is required.");
    }

    function validateBlockName() {
        return validateInput("block_name", isNotEmpty, "Block Name is required.");
    }

    function validateType() {
        return validateInput("type", isNotEmpty, "Type is required.");
    }

    function validateTotalQuarters() {
        return validateInput("total_quarters", isPositiveNumber, "Enter a valid number for Total Quarters.");
    }

    function validateAllottedQuarters() {
        return validateInput("allotted_quarters", isPositiveNumber, "Enter a valid number for Allotted Quarters.");
    }

    function validateVacancies() {
        return validateInput("vacancies", isPositiveNumber, "Enter a valid number for Vacancies.");
    }

    // Real-time validation for each field
    window.onload = function () {
        document.getElementById("campus_name").addEventListener("input", validateCampusName);
        document.getElementById("block_name").addEventListener("input", validateBlockName);
        document.getElementById("type").addEventListener("input", validateType);
        document.getElementById("total_quarters").addEventListener("input", validateTotalQuarters);
        document.getElementById("allotted_quarters").addEventListener("input", validateAllottedQuarters);
        document.getElementById("vacancies").addEventListener("input", validateVacancies);

        // Attach form validation on submit
        document.querySelector("form").addEventListener("submit", function(event) {
            const isCampusNameValid = validateCampusName();
            const isBlockNameValid = validateBlockName();
            const isTypeValid = validateType();
            const isTotalQuartersValid = validateTotalQuarters();
            const isAllottedQuartersValid = validateAllottedQuarters();
            const isVacanciesValid = validateVacancies();

            // Prevent form submission if any validation fails
            if (!(isCampusNameValid && isBlockNameValid && isTypeValid && isTotalQuartersValid && isAllottedQuartersValid && isVacanciesValid)) {
                event.preventDefault();
            }
        });
    };
</script>

</body>


</html>

<?php $conn->close(); ?>