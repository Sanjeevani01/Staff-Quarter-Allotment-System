<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: /sqms/admin/login.php"); // Redirect to login if not logged in or not 'Principle'
    exit();
}
?>

<?php
// Database connection
$servername = "localhost";
$username = "root"; // Database username
$password = ""; // Database password
$dbname = "sqms"; // Your database name
$port = 3308;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle approve/decline actions

// Check if 'id' and 'action' are passed
if (isset($_GET['id']) && isset($_GET['action'])) {
    $fac_id_fk = $_GET['id'];
    $action = $_GET['action'];

    // Prepare the SQL query based on action
    if ($action == 'approve') {
        // Update the status to 'Approved' in the personal_info table
        $sql = "UPDATE personal_info SET admin_status = 'Approved' WHERE fac_id_fk = ?";
    } elseif ($action == 'decline') {
        // Update the status to 'Declined' in the personal_info table
        $sql = "UPDATE personal_info SET admin_status = 'Declined' WHERE fac_id_fk = ?";
    } else {
        // Invalid action
        echo "Invalid action.";
        exit();
    }

    // Prepare and execute the query
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param('s', $fac_id_fk);
        if ($stmt->execute()) {
            echo "Request " . ucfirst($action) . "d successfully.";
            // Redirect after action is complete
            echo "<meta http-equiv='refresh' content='2;url=dashboard.php'>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing the statement: " . $conn->error;
    }
} else {
    echo "Invalid request parameters.";
}

$conn->close();
?>

